package plz.lizi.supersteve.client.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemDisplayContext;
import plz.lizi.supersteve.entity.SuperSteveEntityBase;

public class SSFloatWeaponLayer extends RenderLayer<SuperSteveEntityBase, HumanoidModel<SuperSteveEntityBase>> {
	private final float range;
	private final float time;
	private final int count;
	//private final Vector3f ROAT = new Vector3f(SSUtil.randfloat(-5F, 5F), SSUtil.randfloat(-5F, 5F), SSUtil.randfloat(-5F, 5F));

	public SSFloatWeaponLayer(RenderLayerParent<SuperSteveEntityBase, HumanoidModel<SuperSteveEntityBase>> parent, float range, int count, float time) {
		super(parent);
		this.range = range * 2;
		this.count = count;
		this.time = time;
	}

	@Override
	public void render(PoseStack poseStack, MultiBufferSource buffer, int packedLight, SuperSteveEntityBase entity, float limbSwing, float limbSwingAmount, float partialTick, float ageInTicks, float netHeadYaw, float headPitch) {
		float totalTime = entity.ssGetTick() + partialTick;
		float timeFactor = (float) (totalTime * 2 * Math.PI / this.time);
		poseStack.pushPose();
		SuperSteveRenderer.fixRot(poseStack, entity, partialTick);
		poseStack.translate(0.0F, 0.4F, 0.0F);
		for (int i = 0; i < count; i++) {
			poseStack.pushPose();
			float angle = timeFactor + (float) (i * 2 * Math.PI / this.count);
			float x = (float) (this.range * Math.cos(angle));
			float z = (float) (this.range * Math.sin(angle));
			float y = (float) (0.3F * Math.sin(totalTime * Math.PI * 0.05F));
			poseStack.translate(x, y, z);
			poseStack.mulPose(Axis.YP.rotation(-angle));
			//poseStack.mulPose(Axis.ZP.rotationDegrees(-90.0F));
			poseStack.mulPose(Axis.YP.rotationDegrees(45.0F));
			poseStack.mulPose(Axis.XP.rotationDegrees(90.0F));
			Minecraft.getInstance().getItemRenderer().renderStatic(entity.getItemInHand(InteractionHand.MAIN_HAND), ItemDisplayContext.GROUND, LightTexture.pack(15, 15), OverlayTexture.NO_OVERLAY, poseStack, buffer, entity.level(), 0);
			poseStack.popPose();
		}
		poseStack.popPose();
	}

	public static void renderLineCube(PoseStack poseStack, VertexConsumer vc, float h, float r, float g, float b, float a) {
		PoseStack.Pose pose = poseStack.last();
		float x1 = -h, x2 = h, y1 = -h, y2 = h, z1 = -h, z2 = h;
		line(vc, pose, x1, y1, z1, x2, y1, z1, r, g, b, a);
		line(vc, pose, x2, y1, z1, x2, y2, z1, r, g, b, a);
		line(vc, pose, x2, y2, z1, x1, y2, z1, r, g, b, a);
		line(vc, pose, x1, y2, z1, x1, y1, z1, r, g, b, a);
		line(vc, pose, x1, y1, z2, x2, y1, z2, r, g, b, a);
		line(vc, pose, x2, y1, z2, x2, y2, z2, r, g, b, a);
		line(vc, pose, x2, y2, z2, x1, y2, z2, r, g, b, a);
		line(vc, pose, x1, y2, z2, x1, y1, z2, r, g, b, a);
		line(vc, pose, x1, y1, z1, x1, y1, z2, r, g, b, a);
		line(vc, pose, x2, y1, z1, x2, y1, z2, r, g, b, a);
		line(vc, pose, x2, y2, z1, x2, y2, z2, r, g, b, a);
		line(vc, pose, x1, y2, z1, x1, y2, z2, r, g, b, a);
	}

	private static void line(VertexConsumer vc, PoseStack.Pose pose, float x1, float y1, float z1, float x2, float y2, float z2, float r, float g, float b, float a) {
		vc.vertex(pose.pose(), x1, y1, z1).overlayCoords(0, 10).color(r, g, b, a).normal(pose.normal(), 0, 1, 0).endVertex();
		vc.vertex(pose.pose(), x2, y2, z2).overlayCoords(0, 10).color(r, g, b, a).normal(pose.normal(), 0, 1, 0).endVertex();
	}
}
