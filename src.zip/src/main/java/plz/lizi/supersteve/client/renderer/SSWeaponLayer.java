package plz.lizi.supersteve.client.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.resources.ResourceLocation;
import plz.lizi.supersteve.entity.SuperSteveEntityBase;

public class SSWeaponLayer extends RenderLayer<SuperSteveEntityBase, HumanoidModel<SuperSteveEntityBase>> {
	private static final ResourceLocation WEAPON_CIRCLE = new ResourceLocation("supersteve:textures/entities/ss_weapon_circle.png");
	private final float rotationSpeed;
	private final float floatRange;
	private final float floatSpeed;

	public SSWeaponLayer(RenderLayerParent<SuperSteveEntityBase, HumanoidModel<SuperSteveEntityBase>> parent, float rotationSpeed, float floatRange, float floatSpeed) {
		super(parent);
		this.rotationSpeed = rotationSpeed;
		this.floatRange = floatRange;
		this.floatSpeed = floatSpeed;
	}

	@Override
	public void render(PoseStack poseStack, MultiBufferSource buffer, int packedLight, SuperSteveEntityBase entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
		poseStack.pushPose();
		double time = (entity.ssGetTick() + partialTicks) / floatSpeed;
		double yOffset = Math.sin(time * 2 * Math.PI) * floatRange;
		poseStack.translate(0.0D, -0.5D + yOffset, 0.5D);
		float angle = (entity.ssGetTick() + partialTicks) * rotationSpeed;
		poseStack.mulPose(Axis.ZP.rotationDegrees(angle));
		poseStack.mulPose(Axis.XP.rotationDegrees(180.0F));
		float size = 1.5F;
		poseStack.scale(size, size, size);
		VertexConsumer vertexConsumer = buffer.getBuffer(RenderType.entityCutoutNoCull(WEAPON_CIRCLE));
		PoseStack.Pose pose = poseStack.last();
		packedLight = 0xF000F0;
		vertexConsumer.vertex(pose.pose(), -1.0F, -1.0F, 0.0F).color(255, 255, 255, 255).uv(0.0F, 1.0F).overlayCoords(0, 10).uv2(packedLight).normal(pose.normal(), 0.0F, 0.0F, 1.0F).endVertex();
		vertexConsumer.vertex(pose.pose(), 1.0F, -1.0F, 0.0F).color(255, 255, 255, 255).uv(1.0F, 1.0F).overlayCoords(0, 10).uv2(packedLight).normal(pose.normal(), 0.0F, 0.0F, 1.0F).endVertex();
		vertexConsumer.vertex(pose.pose(), 1.0F, 1.0F, 0.0F).color(255, 255, 255, 255).uv(1.0F, 0.0F).overlayCoords(0, 10).uv2(packedLight).normal(pose.normal(), 0.0F, 0.0F, 1.0F).endVertex();
		vertexConsumer.vertex(pose.pose(), -1.0F, 1.0F, 0.0F).color(255, 255, 255, 255).uv(0.0F, 0.0F).overlayCoords(0, 10).uv2(packedLight).normal(pose.normal(), 0.0F, 0.0F, 1.0F).endVertex();
		poseStack.popPose();
		poseStack.pushPose();
		poseStack.translate(0.0F, 0.5F, 0.0F);
		poseStack.popPose();
	}
}