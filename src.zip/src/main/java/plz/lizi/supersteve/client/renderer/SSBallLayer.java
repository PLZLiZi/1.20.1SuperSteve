package plz.lizi.supersteve.client.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import java.util.HashMap;
import java.util.Map;
import org.joml.Vector3f;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import plz.lizi.supersteve.SuperSteveMod;
import plz.lizi.supersteve.api.SSUtil;
import plz.lizi.supersteve.entity.SuperSteveEntityBase;
import net.minecraft.client.model.HumanoidModel;

public class SSBallLayer extends RenderLayer<SuperSteveEntityBase, HumanoidModel<SuperSteveEntityBase>> {
	private static final ResourceLocation TEX = new ResourceLocation(SuperSteveMod.MODID, "textures/misc/white.png");
	private final Map<Integer, Vector3f> SPHERE_SPEEDS = new HashMap<>();
	private final float count;
	private final float range;
	private final float height;
	private final int segments = 32;

	public SSBallLayer(RenderLayerParent<SuperSteveEntityBase, HumanoidModel<SuperSteveEntityBase>> parent, int count, float range, float height) {
		super(parent);
		this.count = count;
		for (int i = 0; i < count; i++) {
			SPHERE_SPEEDS.put(i, new Vector3f(SSUtil.randfloat(-3F, 3F), SSUtil.randfloat(-3F, 3F), SSUtil.randfloat(-3F, 3F)));
		}
		this.range = range * 2;
		this.height = height;
	}

	@Override
	public void render(PoseStack poseStack, MultiBufferSource buffer, int packedLight, SuperSteveEntityBase entity, float limbSwing, float limbSwingAmount, float partialTick, float ageInTicks, float netHeadYaw, float headPitch) {
		poseStack.pushPose();
		SuperSteveRenderer.fixRot(poseStack, entity, partialTick);
		//poseStack.translate(0, -5.0F, 0);
		float halfH = height / 2.0F;
		float r = 1.0F, g = 1.0F, b = 1.0F, a = 0.3F;
		var color = SSUtil.getRainbowColor(3);
		r = color[0];
		g = color[1];
		b = color[2];
		VertexConsumer vc = buffer.getBuffer(RenderType.entityTranslucentEmissive(TEX, true));
		for (int i = 0; i < count; i++) {
			poseStack.pushPose();
			poseStack.mulPose(Axis.XP.rotationDegrees((entity.ssGetTick() + partialTick) * SPHERE_SPEEDS.get(i).x));
			poseStack.mulPose(Axis.YP.rotationDegrees((entity.ssGetTick() + partialTick) * SPHERE_SPEEDS.get(i).y));
			poseStack.mulPose(Axis.ZP.rotationDegrees((entity.ssGetTick() + partialTick) * SPHERE_SPEEDS.get(i).z));
			drawCylinderSide(poseStack, vc, range + (i * 0.3F), halfH + (i * 0.04F), segments, r, g, b, a, packedLight);
			poseStack.popPose();
		}
		poseStack.popPose();
	}

	private static void drawCylinderSide(PoseStack poseStack, VertexConsumer vc, float range, float halfH, int seg, float r, float g, float b, float a, int packedLight) {
		PoseStack.Pose m = poseStack.last();
		for (int i = 0; i < seg; i++) {
			float a0 = (float) (2 * Math.PI * (i / (float) seg));
			float a1 = (float) (2 * Math.PI * ((i + 1F) / seg));
			float x0 = Mth.cos(a0) * range;
			float z0 = Mth.sin(a0) * range;
			float x1 = Mth.cos(a1) * range;
			float z1 = Mth.sin(a1) * range;
			float U = halfH;
			float D = -halfH;
			vc.vertex(m.pose(), x0, U, z0).color(r, g, b, a).uv(0, 0).overlayCoords(0, 10).uv2(packedLight).normal(m.normal(), x0, 0, z0).endVertex();
			vc.vertex(m.pose(), x0, D, z0).color(r, g, b, a).uv(0, 1).overlayCoords(0, 10).uv2(packedLight).normal(m.normal(), x0, 0, z0).endVertex();
			vc.vertex(m.pose(), x1, D, z1).color(r, g, b, a).uv(1, 1).overlayCoords(0, 10).uv2(packedLight).normal(m.normal(), x1, 0, z1).endVertex();
			vc.vertex(m.pose(), x1, U, z1).color(r, g, b, a).uv(1, 0).overlayCoords(0, 10).uv2(packedLight).normal(m.normal(), x1, 0, z1).endVertex();
		}
	}
}
