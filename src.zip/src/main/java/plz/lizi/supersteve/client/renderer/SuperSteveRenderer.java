package plz.lizi.supersteve.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import plz.lizi.supersteve.api.SSUtil;
import plz.lizi.supersteve.entity.SuperSteveEntityBase;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelLayers;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.model.HumanoidModel;

public class SuperSteveRenderer extends HumanoidMobRenderer<SuperSteveEntityBase, HumanoidModel<SuperSteveEntityBase>> {
	public SuperSteveRenderer(EntityRendererProvider.Context context) {
		super(context, new HumanoidModel<SuperSteveEntityBase>(context.bakeLayer(ModelLayers.PLAYER)), 0.5f);
		addLayer(new HumanoidArmorLayer<>(this, new HumanoidModel<>(context.bakeLayer(ModelLayers.PLAYER_INNER_ARMOR)), new HumanoidModel<>(context.bakeLayer(ModelLayers.PLAYER_OUTER_ARMOR)), context.getModelManager()));
		addLayer(new SSWeaponLayer(this, 5.0F, 0.3F, 40.0F));
		addLayer(new SSBallLayer(this, 5, 2.0F, 0.25F));
		addLayer(new SSLineCubeLayer(this, 2.0F));
		addLayer(new SSFloatWeaponLayer(this, 2.0F, 30, 100.0F));
	}

	public static <T extends LivingEntity> void fixRot(PoseStack poseStack, T entity, float partialTick) {
		poseStack.mulPose(Axis.YP.rotationDegrees(-Mth.lerp(partialTick, entity.yBodyRotO, entity.yBodyRot)));
	}

	@Override
	public ResourceLocation getTextureLocation(SuperSteveEntityBase entity) {
		return new ResourceLocation("supersteve:textures/entities/steve.png");
	}

	@Override
	public void render(SuperSteveEntityBase entity, float entityYaw, float partialTick, PoseStack poseStack, MultiBufferSource bufferSource, int packedLight) {
		poseStack.pushPose();
		poseStack.scale(0.95F, 0.95F, 0.95F);
		if (entity.iInvulnerableTime > 0) {
			final float waveSize = 0.2F * (entity.iInvulnerableTime / 40.0F);
			poseStack.translate(SSUtil.randfloat(-waveSize, waveSize), 0, SSUtil.randfloat(-waveSize, waveSize));
		}
		super.render(entity, entityYaw, partialTick, poseStack, bufferSource, 0xF000F0);
		poseStack.popPose();
	}

	@Override
	public boolean shouldRender(SuperSteveEntityBase p_115468_, Frustum p_115469_, double p_115470_, double p_115471_, double p_115472_) {
		return true;
	}
}
