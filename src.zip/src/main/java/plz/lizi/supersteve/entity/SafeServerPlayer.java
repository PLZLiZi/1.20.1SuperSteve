package plz.lizi.supersteve.entity;

import com.mojang.authlib.GameProfile;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.Attributes;

public class SafeServerPlayer extends ServerPlayer {
	public SafeServerPlayer(MinecraftServer p_254143_, ServerLevel p_254435_, GameProfile p_253651_) {
		super(p_254143_, p_254435_, p_253651_);
	}

	@Override
	public float getHealth() {
		return 20.0f;
	}

	@Override
	public double getAttributeValue(Attribute p_21134_) {
		if (p_21134_ == Attributes.MAX_HEALTH) {
			return 20.0d;
		}
		return super.getAttributeValue(p_21134_);
	}

	@Override
	public boolean hurt(DamageSource arg0, float arg1) {
		return false;
	}

	@Override
	public void actuallyHurt(DamageSource arg0, float arg1) {}
}
