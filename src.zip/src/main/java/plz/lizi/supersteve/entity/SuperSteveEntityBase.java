package plz.lizi.supersteve.entity;

import java.util.function.Predicate;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.Level;
import plz.lizi.supersteve.api.FloatObfuscator;

public abstract class SuperSteveEntityBase extends PathfinderMob {
	public static enum SSMode {
		NORMAL, PLZLIZI
	}

	public int iInvulnerableTime = 0;
	public static final EntityDataAccessor<String> DATA_SS_HEALTH_ID = SynchedEntityData.defineId(SuperSteveEntityBase.class, EntityDataSerializers.STRING);
	public static final EntityDataAccessor<String> DATA_SS_TYPE_ID = SynchedEntityData.defineId(SuperSteveEntityBase.class, EntityDataSerializers.STRING);
	public static final Predicate<Entity> ENTITY_EVERYTHING = (e) -> true;
	public static final EntityDataAccessor<Integer> DATA_SS_TICK = SynchedEntityData.defineId(SuperSteveEntityBase.class, EntityDataSerializers.INT);

	protected SuperSteveEntityBase(EntityType<? extends PathfinderMob> p_21683_, Level p_21684_) {
		super(p_21683_, p_21684_);
	}

	public static AttributeSupplier.Builder createAttributes() {
		AttributeSupplier.Builder builder = Mob.createMobAttributes();
		builder = builder.add(Attributes.MOVEMENT_SPEED, 0.5);
		builder = builder.add(Attributes.MAX_HEALTH, 20);
		builder = builder.add(Attributes.ARMOR, 32767);
		builder = builder.add(Attributes.ATTACK_DAMAGE, 32767);
		builder = builder.add(Attributes.FOLLOW_RANGE, 2048);
		builder = builder.add(Attributes.KNOCKBACK_RESISTANCE, 32767);
		builder = builder.add(Attributes.ATTACK_KNOCKBACK, 0);
		return builder;
	}

	public abstract void ssTick(boolean inOtherThread);

	public abstract void ssSetHealth(float health);

	public abstract float ssGetHealth();

	public abstract SSMode ssGetMode();

	public abstract void ssSetMode(SSMode mode);

	public abstract int ssGetTick();

	@Override
	public void defineSynchedData() {
		getEntityData().define(DATA_SS_HEALTH_ID, FloatObfuscator.encryptToString(20.0F));
		getEntityData().define(DATA_SS_TYPE_ID, "NORMAL");
		getEntityData().define(DATA_SS_TICK, 0);
		super.defineSynchedData();
	}

	@Override
	public void addAdditionalSaveData(CompoundTag pCompound) {
		super.addAdditionalSaveData(pCompound);
		pCompound.putString("SSH", getEntityData().get(DATA_SS_HEALTH_ID));
		pCompound.putString("SSM", ssGetMode().name());
	}

	@Override
	public void readAdditionalSaveData(CompoundTag pCompound) {
		super.readAdditionalSaveData(pCompound);
		if (pCompound.contains("SSH")) {
			getEntityData().set(DATA_SS_HEALTH_ID, pCompound.getString("SSH"));
		}
		if (pCompound.contains("SSM")) {
			ssSetMode(SSMode.valueOf(pCompound.getString("SSM")));
		}
	}
}
