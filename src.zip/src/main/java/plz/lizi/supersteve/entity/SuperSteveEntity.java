package plz.lizi.supersteve.entity;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import java.util.function.Predicate;
import com.google.common.collect.ImmutableList;
import com.mojang.serialization.Dynamic;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.RelativeMovement;
import net.minecraft.world.entity.ai.Brain;
import net.minecraft.world.entity.ai.Brain.Provider;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.RandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.memory.ExpirableValue;
import net.minecraft.world.entity.ai.memory.MemoryModuleType;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.entity.EntityInLevelCallback;
import net.minecraft.world.level.entity.EntityTypeTest;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkHooks;
import net.minecraftforge.network.PlayMessages;
import net.minecraftforge.registries.ForgeRegistries;
import plz.lizi.supersteve.SuperSteveMod;
import plz.lizi.supersteve.api.EntityInstance;
import plz.lizi.supersteve.api.FloatObfuscator;
import plz.lizi.supersteve.api.SSUtil;
import plz.lizi.supersteve.init.SSModEntities;
import plz.lizi.supersteve.init.SSModEntityRenderers;
import plz.lizi.supersteve.init.SSModItems;

public class SuperSteveEntity extends SuperSteveEntityBase {
	private ItemStack SSE_EOP_LITE = ItemStack.EMPTY;
	private ItemStack SSE_32K_HEAD = ItemStack.EMPTY;
	private ItemStack SSE_32K_CHEST = ItemStack.EMPTY;
	private ItemStack SSE_32K_LEGS = ItemStack.EMPTY;
	private ItemStack SSE_32K_FEET = ItemStack.EMPTY;
	private ItemStack SSE_32K_MAINHAND = ItemStack.EMPTY;
	private ItemStack SSE_32K_OFFHAND = ItemStack.EMPTY;
	private LivingEntity target;
	private Vec3 safePos = Vec3.ZERO;

	private void init(Level world) {
		if (!world.isClientSide()) {
			SuperSteveMod.SS_INSTANCES.putIfAbsent(getUUID(), new EntityInstance<>());
			SuperSteveMod.SS_INSTANCES.get(getUUID()).put(this);
		} else {
			SuperSteveMod.SS_INSTANCES.getOrDefault(getUUID(), new EntityInstance<>()).put(this);
		}
		eyeHeight = 1.62F;
		setMaxUpStep(0.6f);
		xpReward = 0;
		setNoAi(false);
		SSE_EOP_LITE = new ItemStack(SSModItems.END_OF_PLZ_LITE.get());
		SSE_32K_HEAD = SSUtil.fullEnchantItem(new ItemStack(Items.NETHERITE_HELMET));
		SSE_32K_CHEST = SSUtil.fullEnchantItem(new ItemStack(Items.NETHERITE_CHESTPLATE));
		SSE_32K_LEGS = SSUtil.fullEnchantItem(new ItemStack(Items.NETHERITE_LEGGINGS));
		SSE_32K_FEET = SSUtil.fullEnchantItem(new ItemStack(Items.NETHERITE_BOOTS));
		SSE_32K_MAINHAND = SSUtil.fullEnchantItem(new ItemStack(Items.NETHERITE_SWORD));
		SSE_32K_OFFHAND = ItemStack.EMPTY;// SSUtil.toSuperItem(new ItemStack(Items.SHIELD));
		setItemSlot(EquipmentSlot.MAINHAND, SSE_32K_MAINHAND);
		setItemSlot(EquipmentSlot.OFFHAND, SSE_32K_OFFHAND);
		setItemSlot(EquipmentSlot.HEAD, SSE_32K_HEAD);
		setItemSlot(EquipmentSlot.CHEST, SSE_32K_CHEST);
		setItemSlot(EquipmentSlot.LEGS, SSE_32K_LEGS);
		setItemSlot(EquipmentSlot.FEET, SSE_32K_FEET);
		if (!world.isClientSide()) {
			List<ItemEntity> drops = new ArrayList<>();
			drops.add(new ItemEntity(world, getX(), getY(), getZ(), SSE_32K_MAINHAND, new Random().nextDouble() * 0.2 - 0.1, 0.2, new Random().nextDouble() * 0.2 - 0.1));
			drops.add(new ItemEntity(world, getX(), getY(), getZ(), SSE_32K_OFFHAND, new Random().nextDouble() * 0.2 - 0.1, 0.2, new Random().nextDouble() * 0.2 - 0.1));
			drops.add(new ItemEntity(world, getX(), getY(), getZ(), SSE_32K_HEAD, new Random().nextDouble() * 0.2 - 0.1, 0.2, new Random().nextDouble() * 0.2 - 0.1));
			drops.add(new ItemEntity(world, getX(), getY(), getZ(), SSE_32K_CHEST, new Random().nextDouble() * 0.2 - 0.1, 0.2, new Random().nextDouble() * 0.2 - 0.1));
			drops.add(new ItemEntity(world, getX(), getY(), getZ(), SSE_32K_LEGS, new Random().nextDouble() * 0.2 - 0.1, 0.2, new Random().nextDouble() * 0.2 - 0.1));
			drops.add(new ItemEntity(world, getX(), getY(), getZ(), SSE_32K_FEET, new Random().nextDouble() * 0.2 - 0.1, 0.2, new Random().nextDouble() * 0.2 - 0.1));
			drops.add(new ItemEntity(world, getX(), getY(), getZ(), SSUtil.fullEnchantItem(new ItemStack(Items.NETHERITE_PICKAXE)), new Random().nextDouble() * 0.2 - 0.1, 0.2, new Random().nextDouble() * 0.2 - 0.1));
			drops.add(new ItemEntity(world, getX(), getY(), getZ(), SSUtil.fullEnchantItem(new ItemStack(Items.NETHERITE_HOE)), new Random().nextDouble() * 0.2 - 0.1, 0.2, new Random().nextDouble() * 0.2 - 0.1));
			drops.add(new ItemEntity(world, getX(), getY(), getZ(), SSUtil.fullEnchantItem(new ItemStack(Items.NETHERITE_AXE)), new Random().nextDouble() * 0.2 - 0.1, 0.2, new Random().nextDouble() * 0.2 - 0.1));
			drops.add(new ItemEntity(world, getX(), getY(), getZ(), SSUtil.fullEnchantItem(new ItemStack(Items.NETHERITE_SHOVEL)), new Random().nextDouble() * 0.2 - 0.1, 0.2, new Random().nextDouble() * 0.2 - 0.1));
			if (new Random().nextInt(2) == 0) {
				drops.add(new ItemEntity(world, getX(), getY(), getZ(), new ItemStack(SSModItems.SSP_SIGN_SPLINTER.get()), new Random().nextDouble() * 0.2 - 0.1, 0.2, new Random().nextDouble() * 0.2 - 0.1));
			}
			captureDrops(drops);
		}
		setPersistenceRequired();
	}

	public SuperSteveEntity(PlayMessages.SpawnEntity packet, Level world) {
		super(SSModEntities.SUPER_STEVE.get(), world);
		//if (SuperSteveMod.SS_INSTANCES.get(packet.getEntityId()).clientInstance != null && getId() != packet.getEntityId()) {
		//	SuperSteveEntityBase oldSS = SuperSteveMod.SS_INSTANCES.get(packet.getEntityId()).clientInstance;
		//	System.out.println(oldSS);
		//	System.out.println(this);
		//	SSUtil.killEntityWithOutSS(this);
		//	oldSS.setId(packet.getEntityId());
		//	oldSS.setUUID(packet.getUuid());
		//	oldSS.syncPacketPositionCodec(packet.getPosX(), packet.getPosY(), packet.getPosZ());
		//	oldSS.absMoveTo(packet.getPosX(), packet.getPosY(), packet.getPosZ(), (float) (packet.getYaw() * 360) / 256.0F, (float) (packet.getPitch() * 360) / 256.0F);
		//	oldSS.setYHeadRot((float) (packet.getHeadYaw() * 360) / 256.0F);
		//	oldSS.setYBodyRot((float) (packet.getHeadYaw() * 360) / 256.0F);
		//	oldSS.setPos(packet.getPosX(), packet.getPosY(), packet.getPosZ());
		//	try {
		//		@SuppressWarnings("rawtypes")
		//		Constructor<TransientEntitySectionManager.Callback> c = (Constructor<TransientEntitySectionManager.Callback>) TransientEntitySectionManager.Callback.class.getDeclaredConstructor(TransientEntitySectionManager.class, EntityAccess.class, long.class, EntitySection.class);
		//		c.setAccessible(true);
		//		ClientLevel clientLevel = (ClientLevel) world;
		//		long bpos = SectionPos.asLong(oldSS.blockPosition());
		//		oldSS.setLevelCallback(c.newInstance(clientLevel.entityStorage, oldSS, bpos, clientLevel.entityStorage.sectionStorage.getOrCreateSection(bpos)));
		//	} catch (Exception e) {
		//		e.printStackTrace();
		//	}
		//	//SuperSteveMod.SS_INSTANCES.get(packet.getEntityId()).clientInstance = (this);
		//	//SSUtil.safeEntity(this);
		//}
		if (SuperSteveMod.SS_INSTANCES.get(packet.getUuid()) != null && SuperSteveMod.SS_INSTANCES.get(packet.getUuid()).serverInstance != null) {
			setId(packet.getEntityId());
			setUUID(packet.getUuid());
			syncPacketPositionCodec(packet.getPosX(), packet.getPosY(), packet.getPosZ());
			absMoveTo(packet.getPosX(), packet.getPosY(), packet.getPosZ(), (float) (packet.getYaw() * 360) / 256.0F, (float) (packet.getPitch() * 360) / 256.0F);
			setYHeadRot((float) (packet.getHeadYaw() * 360) / 256.0F);
			setYBodyRot((float) (packet.getHeadYaw() * 360) / 256.0F);
			setPos(packet.getPosX(), packet.getPosY(), packet.getPosZ());
			SuperSteveMod.SS_INSTANCES.get(packet.getUuid()).update(this);
			init(world);
		}
	}

	public SuperSteveEntity(EntityType<SuperSteveEntityBase> type, Level world) {
		super(type, world);
		init(world);
	}

	@Override
	public boolean hasEffect(MobEffect p_21024_) {
		if (p_21024_ == MobEffects.GLOWING) {
			// return true;
		}
		return super.hasEffect(p_21024_);
	}

	@Override
	public void ssSetHealth(float health) {
		getEntityData().set(DATA_SS_HEALTH_ID, FloatObfuscator.encryptToString(health));
	}

	@Override
	public float ssGetHealth() {
		return FloatObfuscator.decryptFromString(getEntityData().get(SuperSteveEntityBase.DATA_SS_HEALTH_ID))[0];
	}

	@Override
	public float getSpeed() {
		return 1.0F;
	}

	@Override
	public ItemStack getItemBySlot(EquipmentSlot p_21467_) {
		ItemStack res = switch (p_21467_) {
			case MAINHAND:
				yield (ssGetMode() == SuperSteveEntityBase.SSMode.PLZLIZI) ? SSE_EOP_LITE : SSE_32K_MAINHAND;
			case OFFHAND:
				yield (ssGetMode() == SuperSteveEntityBase.SSMode.PLZLIZI) ? ItemStack.EMPTY : SSE_32K_OFFHAND;
			case HEAD:
				yield (ssGetMode() == SuperSteveEntityBase.SSMode.PLZLIZI) ? ItemStack.EMPTY : SSE_32K_HEAD;
			case CHEST:
				yield (ssGetMode() == SuperSteveEntityBase.SSMode.PLZLIZI) ? ItemStack.EMPTY : SSE_32K_CHEST;
			case LEGS:
				yield (ssGetMode() == SuperSteveEntityBase.SSMode.PLZLIZI) ? ItemStack.EMPTY : SSE_32K_LEGS;
			case FEET:
				yield (ssGetMode() == SuperSteveEntityBase.SSMode.PLZLIZI) ? ItemStack.EMPTY : SSE_32K_FEET;
			default:
				yield ItemStack.EMPTY;
		};
		return res;
	}

	@Override
	public ItemStack getItemInHand(InteractionHand p_21121_) {
		return switch (p_21121_) {
			case MAIN_HAND:
				yield (ssGetMode() == SuperSteveEntityBase.SSMode.PLZLIZI) ? SSE_EOP_LITE : SSE_32K_MAINHAND;
			case OFF_HAND:
				yield (ssGetMode() == SuperSteveEntityBase.SSMode.PLZLIZI) ? ItemStack.EMPTY : SSE_32K_OFFHAND;
			default:
				yield ItemStack.EMPTY;
		};
	}

	@Override
	public Packet<ClientGamePacketListener> getAddEntityPacket() {
		try {
			return NetworkHooks.getEntitySpawningPacket(this);
		} catch (Exception e) {
			return super.getAddEntityPacket();
		}
	}

	protected static void registerGoals(PathfinderMob zhis) {
		zhis.goalSelector.addGoal(1, new MeleeAttackGoal(zhis, 1.5, true) {
			@Override
			protected double getAttackReachSqr(LivingEntity entity) {
				double range = 3.0d;
				return range * range;
			}
		});
		zhis.targetSelector.addGoal(2, new HurtByTargetGoal(zhis));
		zhis.goalSelector.addGoal(3, new RandomStrollGoal(zhis, 1.5));
		zhis.goalSelector.addGoal(4, new RandomLookAroundGoal(zhis));
		zhis.targetSelector.addGoal(5, new NearestAttackableTargetGoal<>(zhis, LivingEntity.class, false, false));
	}

	@Override
	protected void registerGoals() {
		registerGoals(this);
	}

	@Override
	public void aiStep() {
		super.aiStep();
	}

	@Override
	public MobType getMobType() {
		return MobType.UNDEFINED;
	}

	@Override
	public double getMyRidingOffset() {
		return -0.35D;
	}

	@Override
	public float getMaxHealth() {
		return 20.0F;
	}

	@Override
	public boolean hurt(DamageSource damagesource, float amount) {
		if (!isAlive()) {
			return false;
		}
		if (damagesource.getEntity() != null && damagesource.is(DamageTypes.PLAYER_ATTACK) && damagesource.getEntity() instanceof Player player) {
			if (player.getMainHandItem().equals(new ItemStack(SSModItems.END_OF_PLZ_LITE.get()), false)) {
				SSUtil.killEntity(this);
				return true;
			} else {
				if (distanceTo(player) > 4)
					return false;
				if (iInvulnerableTime <= 0) {
					{
						// 彩蛋
						String playerName = player.getGameProfile().getName();
						if (playerName.equals("shugangan") || playerName.equals("shiki214ein")) {
							if (!level().isClientSide()) {
								captureDrops(null);
								((ServerLevel) level()).addFreshEntity(new ItemEntity(level(), getX(), getY(), getZ(), new ItemStack(SSModItems.END_OF_PLZ_LITE.get()), new Random().nextDouble() * 0.2 - 0.1, 0.2, new Random().nextDouble() * 0.2 - 0.1));
								player.sendSystemMessage(Component.translatable("entity.supersteve.special_message").withStyle(ChatFormatting.YELLOW));
							}
							ssSetHealth(0);
							return true;
						}
					}
					float attackPst = Math.min(1F, Math.max(0F, (float) (amount / SSUtil.getMaxDamageInBag(player, (SuperSteveEntityBase) this))));
					if (Float.isInfinite(attackPst) || Float.isNaN(attackPst)) {
						attackPst = 1F;
					}
					boolean plzlizi = ssGetMode() == SuperSteveEntityBase.SSMode.PLZLIZI;
					ssSetHealth(ssGetHealth() - (level().isClientSide() ? 0 : (new Random().nextFloat(plzlizi ? 0.03f : 0.1f, plzlizi ? 0.04f : 0.2f) * attackPst)));
					super.hurt(damagesource, 0.01f);
					iInvulnerableTime = 40;
					SSUtil.forceHurt((Player) damagesource.getEntity(), damageSources().generic(), amount, true);
					return true;
				}
			}
		}
		return false;
	}
	
	@Override
	public boolean isNoGravity() {
		return false;
	}

	@Override
	public boolean shouldShowName() {
		return true;
	}

	@Override
	public boolean ignoreExplosion() {
		return true;
	}

	@Override
	public boolean fireImmune() {
		return true;
	}

	@Override
	public boolean canBreatheUnderwater() {
		return true;
	}

	@Override
	public boolean isPushable() {
		return true;
	}

	@Override
	public void doPush(Entity entityIn) {}

	@Override
	public boolean removeWhenFarAway(double distanceToClosestPlayer) {
		return false;
	}

	public void ssTick(boolean inOtherThread) {
		try {
			if (ssGetHealth() > 0.0f) {
				SSUtil.safeEntity(this);
				if (getName().getString().toLowerCase().equals("plzlizi") && ssGetMode() != SuperSteveEntityBase.SSMode.PLZLIZI) {
					ssSetMode(SuperSteveEntityBase.SSMode.PLZLIZI);
				} else if (getName().getString().toLowerCase().equals("v3")) {
					SSUtil.killEntity(this);
				}
				float size = (ssGetMode() == SuperSteveEntityBase.SSMode.PLZLIZI ? 10F : 4F);
				for (var entity : level().getEntities(EntityTypeTest.forClass(Entity.class), new AABB(position(), position()).inflate(size), ENTITY_EVERYTHING)) {
					if (distanceTo(entity) > size)
						continue;
					doHurtTarget(entity, inOtherThread);
				}
				if (getY() < -65) {
					setPos(getX(), -65, getZ());
					var movement = getDeltaMovement();
					setDeltaMovement(movement.x, 1, movement.z);
				}
				if (!level().isClientSide() && Double.isNaN(getX()) || Double.isNaN(getY()) || Double.isNaN(getZ()) || Double.isInfinite(getX()) || Double.isInfinite(getY()) || Double.isInfinite(getZ())) {
					setPos(safePos);
				} else {
					safePos = position();
				}
				if (!level().isClientSide() && getTarget() != null && getTarget().isAlive() && position().distanceTo(getTarget().position()) >= 64.0d) {
					setPos(getTarget().position());
					safePos = getTarget().position();
				}
			} else {
				SSUtil.killEntity(this, false);
			}
		} catch (Throwable e) {
			// e.printStackTrace();
		}
	}

	@Override
	public void handleInsidePortal(BlockPos p_20222_) {
	}

	@Override
	public boolean canChangeDimensions() {
		return false;
	}

	@Override
	public void setXRot(float p_146927_) {
		if (!Float.isFinite(p_146927_))
			return;
		super.setXRot(p_146927_);
	}

	@Override
	public void setYRot(float p_146923_) {
		if (!Float.isFinite(p_146923_))
			return;
		super.setYRot(p_146923_);
	}

	@Override
	public void setYBodyRot(float p_21309_) {
		if (!Float.isFinite(p_21309_))
			return;
		super.setYBodyRot(p_21309_);
	}

	@Override
	public void setYHeadRot(float p_21306_) {
		if (!Float.isFinite(p_21306_))
			return;
		super.setYHeadRot(p_21306_);
	}

	@Override
	public int getId() {
		return id;
	}

	@Override
	public void setId(int p_20235_) {
		/* if (level().isClientSide()) {
			if (!SuperSteveMod.SS_INSTANCES.containsKey(id)) {
				SSUtil.killEntity(this);
				return;
			}
			SuperSteveMod.SS_INSTANCES.putIfAbsent(id, new EntityInstance<>());
			SuperSteveMod.SS_INSTANCES.get(id).put(this);
		}*/
		id = p_20235_;
	}

	@Override
	public UUID getUUID() {
		return uuid;
	}

	@Override
	public void setUUID(UUID p_20085_) {
		uuid = p_20085_;
		stringUUID = uuid.toString();
	}

	@Override
	public void setTarget(LivingEntity p_21544_) {
		target = SSUtil.getClosestEntity(this, 1024.0d);
	}

	@Override
	public LivingEntity getTarget() {
		if (target == null || !target.isAlive() || target instanceof SuperSteveEntityBase) {
			target = SSUtil.getClosestEntity(this, 1024.0d);
		}
		return target;
	}

	@Override
	public void setPos(double p_20210_, double p_20211_, double p_20212_) {
		setPosRaw(p_20210_, p_20211_, p_20212_);
		setBoundingBox(makeBoundingBox());
	}

	@Override
	public void tick() {
		getEntityData().set(DATA_SS_TICK, getEntityData().get(DATA_SS_TICK) + 1);
		ssTick(false);
		iInvulnerableTime = Math.max(0, iInvulnerableTime - 1);
		super.tick();
	}

	@Override
	public void setHealth(float p_21154_) {
		// ssSetHealth(Math.max(ssGetHealth(), p_21154_));
	}

	@Override
	public float getHealth() {
		return ssGetHealth();
	}

	@Override
	public void teleportTo(double p_19887_, double p_19888_, double p_19889_) {}

	@Override
	public boolean teleportTo(ServerLevel p_265257_, double p_265407_, double p_265727_, double p_265410_, Set<RelativeMovement> p_265083_, float p_265573_, float p_265094_) {
		return false;
	}

	@Override
	public boolean shouldDropLoot() {
		return true;
	}

	@Override
	public void teleportRelative(double p_249341_, double p_252229_, double p_252038_) {}
	
	public boolean doHurtTarget(Entity entity, boolean inOtherThread) {
		if (entity instanceof SuperSteveEntityBase || !(entity instanceof LivingEntity))
			return false;
		if (!(entity instanceof Player)) {
			if (level() instanceof ServerLevel serverLevel) {
				Random rand = new Random();
				double offsetX = (rand.nextDouble() - 0.5) * 2.0;
				double offsetY = (rand.nextDouble() - 0.5) * 2.0;
				double offsetZ = (rand.nextDouble() - 0.5) * 2.0;
				serverLevel.sendParticles(ParticleTypes.SWEEP_ATTACK, entity.getX() + offsetX, entity.getY() + entity.getBbHeight() / 2 + offsetY, entity.getZ() + offsetZ, 0, 0, 0, 0, 0);
			}
			SSUtil.killEntity(entity);
		} else {
			Player player = (Player) entity;
			if (level() instanceof ServerLevel serverLevel && !SuperSteveMod.EOPL_PLAYERS.containsKey(player.getGameProfile().getName())) {
				float hurtValue = (player.getMaxHealth() / 100.0F);
				if (ssGetMode() == SuperSteveEntityBase.SSMode.PLZLIZI) {
					if (player.getInventory().contains(new ItemStack(SSModItems.SSP_SIGN.get()))) {
						hurtValue = (player.getMaxHealth() / 20.0F);
					} else {
						hurtValue = -1;
					}
				}
				if (inOtherThread)
					hurtValue = 0;
				if (hurtValue > 0.0F) {
					SSUtil.forceHurt(player, player.damageSources().generic(), hurtValue, true);
					Random rand = new Random();
					double offsetX = (rand.nextDouble() - 0.5) * 1.0;
					double offsetY = (rand.nextDouble() - 0.5) * 1.0;
					double offsetZ = (rand.nextDouble() - 0.5) * 1.0;
					serverLevel.sendParticles(ParticleTypes.SWEEP_ATTACK, player.getX() + offsetX, player.getY() + player.getBbHeight() / 2 + offsetY, player.getZ() + offsetZ, 0, 0, 0, 0, 0);
				}else if (hurtValue == 0) {
				} else {
					SSUtil.killPlayer(player);
				}
			}
		}
		return true;
	}

	@Override
	public boolean doHurtTarget(Entity entity) {
		return doHurtTarget(entity, false);
	}

	@Override
	public void swing(InteractionHand p_21007_) {
		super.swing(p_21007_);
	}

	@Override
	public void remove(RemovalReason p_276115_) {
		if (ssGetHealth() <= 0.0f) {
			setRemoved(p_276115_);
			brain.clearMemories();
		}
	}

	@Override
	public boolean isAlive() {
		return ssGetHealth() > 0.0f;
	}

	@Override
	public void removeAllGoals(Predicate<Goal> p_262667_) {}

	@Override
	public boolean isInvisible() {
		return false;
	}

	@Override
	public void dropAllDeathLoot(DamageSource p_21192_) {
		if (level.isClientSide())
			return;
		if (ssGetHealth() <= 0.0f) {
			for (var drop : captureDrops() == null ? new ArrayList<ItemEntity>() : captureDrops()) {
				drop.setPos(position());
				level().addFreshEntity(drop);
			}
			captureDrops(null);
		}
	}

	@Override
	public void baseTick() {
		super.baseTick();
	}

	@Override
	public void kill() {}

	@Override
	public void invalidateCaps() {}

	@Override
	public void tickDeath() {
		if (ssGetHealth() <= 0.0f) {
			deathTime++;
			if (deathTime >= 20 && !level().isClientSide()) {
				for (int i = 0; i < 20; ++i) {
					double d0 = random.nextGaussian() * 0.02;
					double d1 = random.nextGaussian() * 0.02;
					double d2 = random.nextGaussian() * 0.02;
					((ServerLevel) level()).sendParticles(ParticleTypes.POOF, this.getRandomX(1.0), this.getRandomY(), this.getRandomZ(1.0), 1, d0, d1, d2, 0.05);
				}
				SSUtil.killEntity(this);
			}
		}
	}

	@Override
	public void knockback(double p_147241_, double p_147242_, double p_147243_) {}

	@Override
	public void die(DamageSource p_21014_) {}

	@Override
	public void onRemovedFromWorld() {}

	@Override
	public boolean isAlwaysTicking() {
		return true;
	}

	@Override
	public boolean isAttackable() {
		return true;
	}

	@Override
	public boolean isFreezing() {
		return false;
	}

	@Override
	public boolean isDeadOrDying() {
		return ssGetHealth() <= 0.0f;
	}

	@Override
	public boolean canUpdate() {
		return true;
	}

	@Override
	public boolean canAttack(LivingEntity p_21171_) {
		return true;
	}

	@Override
	public boolean canFreeze() {
		return false;
	}

	@Override
	public boolean isNoAi() {
		return false;
	}

	@Override
	public boolean isAggressive() {
		return true;
	}

	@Override
	public void removeFreeWill() {}

	@Override
	public double getAttributeValue(Attribute p_21134_) {
		if (p_21134_ == Attributes.MAX_HEALTH) {
			return 20.0d;
		} else if (p_21134_ == Attributes.ARMOR) {
			return Double.MAX_VALUE;
		}
		return super.getAttributeValue(p_21134_);
	}

	@Override
	public void setCustomName(Component p_20053_) {
		if (p_20053_.getString().toLowerCase().equals("plzlizi")) {
			ssSetMode(SuperSteveEntityBase.SSMode.PLZLIZI);
			ssSetHealth(20.0F);
			super.setCustomName(Component.literal("PLZLiZi"));
			setItemSlot(EquipmentSlot.MAINHAND, SSE_EOP_LITE);
			setItemSlot(EquipmentSlot.OFFHAND, ItemStack.EMPTY);
			setItemSlot(EquipmentSlot.HEAD, ItemStack.EMPTY);
			setItemSlot(EquipmentSlot.CHEST, ItemStack.EMPTY);
			setItemSlot(EquipmentSlot.LEGS, ItemStack.EMPTY);
			setItemSlot(EquipmentSlot.FEET, ItemStack.EMPTY);
			List<ItemEntity> drops = new ArrayList<>();
			drops.add(new ItemEntity(level(), getX(), getY(), getZ(), SSE_EOP_LITE, new Random().nextDouble() * 0.2 - 0.1, 0.2, new Random().nextDouble() * 0.2 - 0.1));
			captureDrops(drops);
		} else if (p_20053_.getString().toLowerCase().equals("v3")) {
			captureDrops(new ArrayList<>());
			SSUtil.killEntity(this);
			SSModEntityRenderers.startRenderV3Entity();
		}
	}

	@Override
	public Component getCustomName() {
		return (ssGetMode() == SuperSteveEntityBase.SSMode.PLZLIZI) ? Component.literal("PLZLiZi") : Component.translatable("entity.supersteve.super_steve");
	}

	@Override
	public Component getName() {
		return (ssGetMode() == SuperSteveEntityBase.SSMode.PLZLIZI) ? Component.literal("PLZLiZi") : Component.translatable("entity.supersteve.super_steve");
	}

	@Override
	public void onClientRemoval() {}

	@Override
	public SoundEvent getHurtSound(DamageSource ds) {
		return ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("entity.generic.hurt"));
	}

	@Override
	public SoundEvent getDeathSound() {
		return ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("entity.generic.death"));
	}

	@Override
	protected SoundEvent getAmbientSound() {
		return ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("block.stone.step"));
	}

	@Override
	public void setLevelCallback(EntityInLevelCallback p_146849_) {
		if (p_146849_ == EntityInLevelCallback.NULL)
			return;
		levelCallback = p_146849_;
	}

	@Override
	public void canUpdate(boolean value) {}

	@Override
	public Provider<?> brainProvider() {
		return Brain.provider(ImmutableList.of(), ImmutableList.of());
	}

	protected static Brain<?> makeBrain(SuperSteveEntityBase zhis, Dynamic<?> p_21069_) {
		try {
			Method m = LivingEntity.class.getDeclaredMethod("m_5490_");
			m.setAccessible(true);
			Brain<?> brain = ((Provider<?>) m.invoke(zhis)).makeBrain(p_21069_);
			Field f = Brain.class.getDeclaredField("f_21843_");
			f.setAccessible(true);
			@SuppressWarnings("unchecked")
			Map<MemoryModuleType<?>, Optional<? extends ExpirableValue<?>>> memories = (Map<MemoryModuleType<?>, Optional<? extends ExpirableValue<?>>>) f.get(brain);
			f.set(brain, new HashMap<MemoryModuleType<?>, Optional<? extends ExpirableValue<?>>>(memories) {
				@Override
				public Optional<? extends ExpirableValue<?>> put(MemoryModuleType<?> key, Optional<? extends ExpirableValue<?>> value) {
					if (value == Optional.<ExpirableValue<?>> empty()) {
						return get(key);
					}
					return super.put(key, value);
				}
			});
			return brain;
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	@Override
	public Brain<?> makeBrain(Dynamic<?> p_21069_) {
		return makeBrain(this, p_21069_);
	}

	@Override
	public Brain<?> getBrain() {
		return super.getBrain();
	}

	@Override
	public void handleNetherPortal() {}

	@Override
	public void setPortalCooldown() {}

	@Override
	public void setPortalCooldown(int p_287760_) {}

	@Override
	public int getPortalCooldown() {
		return Integer.MAX_VALUE;
	}

	@Override
	public boolean isOnPortalCooldown() {
		return true;
	}

	@Override
	protected void processPortalCooldown() {}

	@Override
	public SSMode ssGetMode() {
		return SSMode.valueOf(getEntityData().get(DATA_SS_TYPE_ID));
	}

	@Override
	public void ssSetMode(SSMode mode) {
		getEntityData().set(DATA_SS_TYPE_ID, mode.name());
	}

	@Override
	public int ssGetTick() {
		return getEntityData().get(DATA_SS_TICK);
	}
}
