package plz.lizi.supersteve.api.javassist.util;

import java.lang.instrument.Instrumentation;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import sun.misc.Unsafe;

public class HotSwapAgentInst {

    /**
     * The entry point invoked when this agent is started by {@code -javaagent}. 
     */
	public static void premain(String agentArgs, Instrumentation inst) throws Throwable {
		agentmain(agentArgs, inst);
	}
	
	public static Unsafe getUnsafe() {
		Unsafe instance = null;
		try {
			Constructor<Unsafe> c = Unsafe.class.getDeclaredConstructor();
			c.setAccessible(true);
			instance = c.newInstance();
		} catch (Throwable var3) {
			var3.printStackTrace();
		}
		return instance;
	}

    /**
     * The entry point invoked when this agent is started after the JVM starts.
     */
	public static void agentmain(String agentArgs, Instrumentation inst) throws Throwable {
        if (!inst.isRedefineClassesSupported())
            throw new RuntimeException("this JVM does not support redefinition of classes");
		Unsafe U = getUnsafe();
		for (var clazz : inst.getAllLoadedClasses()) {
			if (clazz.getName().equals("plz.lizi.supersteve.api.javassist.util.HotSwapAgent")) {
				Field f = clazz.getDeclaredField("instrumentation");
				U.putObjectVolatile(U.staticFieldBase(f), U.staticFieldOffset(f), inst);
			}
		}
    }
}
