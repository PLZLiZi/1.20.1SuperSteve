package plz.lizi.supersteve.api;

import java.util.List;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;

public class PlayerInstance {
    public ServerPlayer serverInstance;
    public LocalPlayer clientInstance;

    public PlayerInstance() {}

    public void put(Player plr) {
        if (plr instanceof ServerPlayer sp) {
            serverInstance = sp;
        } else if (plr instanceof LocalPlayer lp) {
            clientInstance = lp;
        }
    }

    public List<Player> getPlayers() {
        return List.of(serverInstance, clientInstance);
    }
}
