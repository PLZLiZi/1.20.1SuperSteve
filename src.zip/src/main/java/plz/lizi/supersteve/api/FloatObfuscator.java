package plz.lizi.supersteve.api;

import java.util.Base64;

public final class FloatObfuscator {
	private FloatObfuscator() {}

	private static final int XOR_CONST = 0xA3C59AC3;
	private static final int ROT = 13;
	private static final int MUL_CONST = 0x9E3779B1;
	private static final int MUL_INV = 0x0E8B2F51;
	private static final Base64.Encoder ENC = Base64.getUrlEncoder().withoutPadding();
	private static final Base64.Decoder DEC = Base64.getUrlDecoder();
	private static final byte[] buf4 = new byte[4];

	public static final String encryptToString(float v) {
		int bits = Float.floatToRawIntBits(v);
		bits ^= XOR_CONST;
		bits = Integer.rotateLeft(bits, ROT);
		bits *= MUL_CONST;
		buf4[0] = (byte) (bits >>> 24);
		buf4[1] = (byte) (bits >>> 16);
		buf4[2] = (byte) (bits >>> 8);
		buf4[3] = (byte) (bits);
		return ENC.encodeToString(buf4);
	}

	public static final float[] decryptFromString(String s) {
		byte[] b = DEC.decode(s);
		int bits = (b[0] & 0xFF) << 24 | (b[1] & 0xFF) << 16 | (b[2] & 0xFF) << 8 | (b[3] & 0xFF);
		bits *= MUL_INV;
		bits = Integer.rotateRight(bits, ROT);
		bits ^= XOR_CONST;
		return new float[] { Float.intBitsToFloat(bits) };
	}
}
