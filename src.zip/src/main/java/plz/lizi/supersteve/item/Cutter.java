package plz.lizi.supersteve.item;

import java.io.ByteArrayInputStream;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.CrashReport;
import net.minecraft.CrashReportCategory;
import net.minecraft.ReportedException;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderDispatcher;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import plz.lizi.supersteve.api.SSUtil;
import plz.lizi.supersteve.api.javassist.ClassPool;
import plz.lizi.supersteve.api.javassist.CtClass;
import plz.lizi.supersteve.api.javassist.CtMethod;
import plz.lizi.supersteve.api.javassist.NotFoundException;
import plz.lizi.supersteve.api.javassist.util.HotSwapAgent;

public class Cutter extends Item {
	public static final ClassPool POOL = ClassPool.getDefault();
	public static final Map<Integer, Float> HEALTH_OFFSET = new HashMap<>();
	public static final Map<Integer, Integer> CLIENT_DEATHTICKS = new HashMap<>();
	public static final Map<Integer, Integer> SERVER_DEATHTICKS = new HashMap<>();
	public static final Set<String> RELOADED_CLASSES = new HashSet<>();

	public Cutter() {
		super(new Properties().stacksTo(1));
	}

	public static float getModifyHealth(LivingEntity entity, float health) {
		return HEALTH_OFFSET.containsKey(entity.getId()) ? Math.max(0, (health - HEALTH_OFFSET.get(entity.getId()))) : health;
	}

	public static boolean onTickStart(LivingEntity entity) {
		if (HEALTH_OFFSET.containsKey(entity.getId()) && HEALTH_OFFSET.get(entity.getId()) >= entity.getMaxHealth()) {
			if (entity.level().isClientSide()) {
				CLIENT_DEATHTICKS.putIfAbsent(entity.getId(), 0);
				CLIENT_DEATHTICKS.put(entity.getId(), CLIENT_DEATHTICKS.get(entity.getId()) + 1);
				if (CLIENT_DEATHTICKS.get(entity.getId()) >= 20) {
					SSUtil.killEntity(entity);
					CLIENT_DEATHTICKS.remove(entity.getId());
				}
			} else {
				SERVER_DEATHTICKS.putIfAbsent(entity.getId(), 0);
				SERVER_DEATHTICKS.put(entity.getId(), SERVER_DEATHTICKS.get(entity.getId()) + 1);
				if (SERVER_DEATHTICKS.get(entity.getId()) >= 20) {
					entity.level().broadcastEntityEvent(entity, (byte) 60);
					SSUtil.killEntity(entity);
					SERVER_DEATHTICKS.remove(entity.getId());
				}
			}
			return false;
		}
		return true;
	}

	public static <E extends Entity> void entityRenderDispatcherRender(EntityRenderDispatcher zhis, E entity, double p_114386_, double p_114387_, double p_114388_, float p_114389_, float practicalTick, PoseStack pose, MultiBufferSource p_114392_, int p_114393_) {
		EntityRenderer<? super E> entityrenderer = zhis.getRenderer(entity);
		try {
			Vec3 vec3 = entityrenderer.getRenderOffset(entity, practicalTick);
			double d2 = p_114386_ + vec3.x();
			double d3 = p_114387_ + vec3.y();
			double d0 = p_114388_ + vec3.z();
			pose.pushPose();
			pose.translate(d2, d3, d0);
			pose.pushPose();
			if (entity instanceof LivingEntity livingEntity && CLIENT_DEATHTICKS.containsKey(entity.getId()) && CLIENT_DEATHTICKS.get(entity.getId()) > 0) {
				float f = ((float) CLIENT_DEATHTICKS.get(entity.getId()) + practicalTick - 1.0F) / 20.0F * 1.6F;
				f = Mth.sqrt(f);
				if (f > 1.0F) {
					f = 1.0F;
				}
				pose.mulPose(Axis.ZP.rotationDegrees(f * 90F));
				livingEntity.hurtTime = 20;
			}
			entityrenderer.render(entity, p_114389_, practicalTick, pose, p_114392_, p_114393_);
			pose.popPose();
			if (entity.displayFireAnimation()) {
				zhis.renderFlame(pose, p_114392_, entity);
			}
			pose.translate(-vec3.x(), -vec3.y(), -vec3.z());
			if ((Boolean) zhis.options.entityShadows().get() && zhis.shouldRenderShadow && entityrenderer.shadowRadius > 0.0F && !entity.isInvisible()) {
				double d1 = zhis.distanceToSqr(entity.getX(), entity.getY(), entity.getZ());
				float f = (float) ((1.0 - d1 / 256.0) * (double) entityrenderer.shadowStrength);
				if (f > 0.0F) {
					EntityRenderDispatcher.renderShadow(pose, p_114392_, entity, f, practicalTick, zhis.level, Math.min(entityrenderer.shadowRadius, 32.0F));
				}
			}
			if (zhis.renderHitBoxes && !entity.isInvisible() && !Minecraft.getInstance().showOnlyReducedInfo()) {
				EntityRenderDispatcher.renderHitbox(pose, p_114392_.getBuffer(RenderType.lines()), entity, practicalTick);
			}
			pose.popPose();
		} catch (Throwable var24) {
			CrashReport crashreport = CrashReport.forThrowable(var24, "Rendering entity in world");
			CrashReportCategory crashreportcategory = crashreport.addCategory("Entity being rendered");
			entity.fillCrashReportCategory(crashreportcategory);
			CrashReportCategory crashreportcategory1 = crashreport.addCategory("Renderer details");
			crashreportcategory1.setDetail("Assigned renderer", entityrenderer);
			crashreportcategory1.setDetail("Location", CrashReportCategory.formatLocation(zhis.level, p_114386_, p_114387_, p_114388_));
			crashreportcategory1.setDetail("Rotation", p_114389_);
			crashreportcategory1.setDetail("Delta", practicalTick);
			throw new ReportedException(crashreport);
		}
	}

	public static void reloadERD() {
		if (RELOADED_CLASSES.contains(EntityRenderDispatcher.class.getName()))
			return;
		try {
			HotSwapAgent.redefine(EntityRenderDispatcher.class, (Class<?> classBeingRedefined, byte[] classFileBuffer) -> {
				CtClass ctClass = POOL.makeClass(new ByteArrayInputStream(classFileBuffer), false);
				if (ctClass.isFrozen())
					ctClass.defrost();
				CtMethod ctMethod = ctClass.getDeclaredMethod("m_114384_");
				ctMethod.setBody("{ plz.lizi.supersteve.item.Cutter.entityRenderDispatcherRender($0, $1, $2, $3, $4, $5, $6, $7, $8, $9); }");
				return ctClass;
			});
			RELOADED_CLASSES.add(EntityRenderDispatcher.class.getName());
		} catch (Throwable e) {
			new RuntimeException(EntityRenderDispatcher.class.getName(), e).printStackTrace();
		}
	}

	public static void reloadEntity(Class<?> clazz) {
		for (Class<?> current = clazz; current != LivingEntity.class.getSuperclass(); current = current.getSuperclass()) {
			try {
				if (RELOADED_CLASSES.contains(current.getName()))
					continue;
				// final Class<?> fCurrent = current;
				HotSwapAgent.redefine(current, (Class<?> classBeingRedefined, byte[] classFileBuffer) -> {
					CtClass ctClass = POOL.makeClass(new ByteArrayInputStream(classFileBuffer), false);
					if (ctClass.isFrozen())
						ctClass.defrost();
					try {
						CtMethod ctMethod = ctClass.getDeclaredMethod("m_21223_");
						ctMethod.insertAfter("{ return plz.lizi.supersteve.item.Cutter.getModifyHealth($0, $_); }");
					} catch (NotFoundException n) {
					} catch (Throwable e2) {
						e2.printStackTrace();
					}
					try {
						CtMethod ctMethod = ctClass.getDeclaredMethod("m_8119_");
						ctMethod.insertBefore("{ if (!plz.lizi.supersteve.item.Cutter.onTickStart($0)) { return; } }");
					} catch (NotFoundException n) {
					} catch (Throwable e2) {
						e2.printStackTrace();
					}
					return ctClass;
				});
				RELOADED_CLASSES.add(current.getName());
			} catch (Throwable e) {
				new RuntimeException(current.getName(), e).printStackTrace();
			}
		}
	}

	@Override
	public boolean hurtEnemy(ItemStack p_41395_, LivingEntity enemy, LivingEntity source) {
		HEALTH_OFFSET.putIfAbsent(enemy.getId(), Math.max(enemy.getHealth(), enemy.getMaxHealth()));
		if (enemy.level().isClientSide()) {
			CLIENT_DEATHTICKS.putIfAbsent(enemy.getId(), 0);
		} else {
			SERVER_DEATHTICKS.putIfAbsent(enemy.getId(), 0);
		}
		reloadEntity(enemy.getClass());
		return false;
	}

	public static List<LivingEntity> getEntities(LivingEntity sourceEntity, double range) {
		Level world = sourceEntity.level();
		AABB searchBox = sourceEntity.getBoundingBox().inflate(range);
		return world.getEntitiesOfClass(LivingEntity.class, searchBox, (entity) -> !(entity instanceof Player));
	}

	@Override
	public boolean onEntitySwing(ItemStack stack, LivingEntity entity) {
		reloadERD();
		for (var e : getEntities(entity, 100)) {
			hurtEnemy(stack, e, entity);
		}
		return super.onEntitySwing(stack, entity);
	}

	@Override
	public void inventoryTick(ItemStack stack, Level level, Entity i, int index, boolean hand) {
		try {
			synchronized (HEALTH_OFFSET) {
				for (Map.Entry<Integer, Float> entry : new HashMap<>(HEALTH_OFFSET).entrySet()) {
					if (!CLIENT_DEATHTICKS.containsKey(entry.getKey()) && !SERVER_DEATHTICKS.containsKey(entry.getKey())) {
						HEALTH_OFFSET.remove(entry.getKey());
					}
				}
			}
		} catch (Throwable e) {
		}
	}
}
