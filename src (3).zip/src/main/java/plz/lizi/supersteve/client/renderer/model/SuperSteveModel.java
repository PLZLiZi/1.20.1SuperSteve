package plz.lizi.supersteve.client.renderer.model;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelPart;
import plz.lizi.supersteve.entity.SuperSteveEntityBase;

public class SuperSteveModel extends HumanoidModel<SuperSteveEntityBase> {

    public SuperSteveModel(ModelPart p_170677_) {
        super(p_170677_);
    }

    @Override
    public void renderToBuffer(PoseStack p_102034_, VertexConsumer p_102035_, int p_102036_, int p_102037_, float p_102038_, float p_102039_, float p_102040_, float p_102041_) {
        super.renderToBuffer(p_102034_, p_102035_, p_102036_, p_102037_, p_102038_, p_102039_, p_102040_, p_102041_);
    }
}
