package plz.lizi.supersteve.client.renderer;

import org.joml.Vector3f;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import plz.lizi.supersteve.api.SSUtil;
import plz.lizi.supersteve.client.renderer.model.SuperSteveModel;
import plz.lizi.supersteve.entity.SuperSteveEntityBase;

public class SSLineCubeLayer extends RenderLayer<SuperSteveEntityBase, SuperSteveModel> {
	private final float range;
	private final Vector3f ROAT = new Vector3f(SSUtil.randfloat(-5F, 5F), SSUtil.randfloat(-5F, 5F), SSUtil.randfloat(-5F, 5F));

	public SSLineCubeLayer(RenderLayerParent<SuperSteveEntityBase, SuperSteveModel> parent, float range) {
		super(parent);
		this.range = range;
	}

	@Override
	public void render(PoseStack poseStack, MultiBufferSource buffer, int packedLight, SuperSteveEntityBase entity, float limbSwing, float limbSwingAmount, float partialTick, float ageInTicks, float netHeadYaw, float headPitch) {
		poseStack.pushPose();
		SuperSteveRenderer.unscale(poseStack);
		SuperSteveRenderer.fixRot(poseStack, entity, partialTick);
		VertexConsumer vc = buffer.getBuffer(RenderType.lines());
		float half = this.range * 0.5f;
		float[] rgb = SSUtil.getRainbowColor(3);
		poseStack.mulPose(Axis.XP.rotationDegrees((entity.ssGetTick() + partialTick) * ROAT.x));
		poseStack.mulPose(Axis.YP.rotationDegrees((entity.ssGetTick() + partialTick) * ROAT.y));
		poseStack.mulPose(Axis.ZP.rotationDegrees((entity.ssGetTick() + partialTick) * ROAT.z));
		renderLineCube(poseStack, vc, half, rgb[0], rgb[1], rgb[2], 1);
		poseStack.popPose();
		//poseStack.translate(-0.5F, -0.5F, -0.5F);
		//Minecraft.getInstance().getBlockRenderer().renderSingleBlock(Blocks.BEDROCK.defaultBlockState(), poseStack, buffer, packedLight, OverlayTexture.NO_OVERLAY, ModelData.EMPTY, null);
		
	}

	private static void renderLineCube(PoseStack poseStack, VertexConsumer vc, float h, float r, float g, float b, float a) {
		PoseStack.Pose pose = poseStack.last();
		float x1 = -h, x2 = h, y1 = -h, y2 = h, z1 = -h, z2 = h;
		line(vc, pose, x1, y1, z1, x2, y1, z1, r, g, b, a);
		line(vc, pose, x2, y1, z1, x2, y2, z1, r, g, b, a);
		line(vc, pose, x2, y2, z1, x1, y2, z1, r, g, b, a);
		line(vc, pose, x1, y2, z1, x1, y1, z1, r, g, b, a);
		line(vc, pose, x1, y1, z2, x2, y1, z2, r, g, b, a);
		line(vc, pose, x2, y1, z2, x2, y2, z2, r, g, b, a);
		line(vc, pose, x2, y2, z2, x1, y2, z2, r, g, b, a);
		line(vc, pose, x1, y2, z2, x1, y1, z2, r, g, b, a);
		line(vc, pose, x1, y1, z1, x1, y1, z2, r, g, b, a);
		line(vc, pose, x2, y1, z1, x2, y1, z2, r, g, b, a);
		line(vc, pose, x2, y2, z1, x2, y2, z2, r, g, b, a);
		line(vc, pose, x1, y2, z1, x1, y2, z2, r, g, b, a);
	}

	private static void line(VertexConsumer vc, PoseStack.Pose pose, float x1, float y1, float z1, float x2, float y2, float z2, float r, float g, float b, float a) {
		vc.vertex(pose.pose(), x1, y1, z1).color(r, g, b, a).normal(pose.normal(), 0, 0, 0).endVertex();
		vc.vertex(pose.pose(), x2, y2, z2).color(r, g, b, a).normal(pose.normal(), 0, 0, 0).endVertex();
	}
}
