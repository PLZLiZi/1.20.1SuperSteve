package plz.lizi.supersteve.api;

public enum SystemProperty {
	UUID;
}
