/*
 * Javassist, a Java-bytecode translator toolkit.
 * Copyright (C) 1999- Shigeru Chiba. All Rights Reserved.
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License.  Alternatively, the contents of this file may be used under
 * the terms of the GNU Lesser General Public License Version 2.1 or later,
 * or the Apache License Version 2.0.
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 */
package plz.lizi.supersteve.api.javassist.util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.instrument.ClassFileTransformer;
import java.lang.instrument.IllegalClassFormatException;
import java.lang.instrument.Instrumentation;
import java.security.ProtectionDomain;
import java.util.HashMap;
import java.util.Map;
import java.util.jar.Attributes;
import java.util.jar.JarEntry;
import java.util.jar.JarOutputStream;
import java.util.jar.Manifest;
import plz.lizi.supersteve.api.PLZBase;
import plz.lizi.supersteve.api.javassist.ClassPool;
import plz.lizi.supersteve.api.javassist.CtClass;

/**
 * A utility class for dynamically adding a new method or modifying an existing method body. This class provides {@link #redefine(Class, CtClass)} and {@link #redefine(Class[], CtClass[])}, which replace the existing class definition with a new one. These methods perform the replacement by {@code java.lang.instrument.Instrumentation}. For details of acceptable modification, see the {@code Instrumentation} interface.
 * <p>
 * Before calling the {@code redefine} methods, the hotswap agent has to be deployed.
 * </p>
 * <p>
 * To create a hotswap agent, run {@link #createAgentJarFile(String)}. For example, the following command creates an agent file named {@code hotswap.jar}.
 *
 * <pre>
 * $ jshell --class-path plz.lizi.supersteve.api.javassist.jar
 * jshell&gt; plz.lizi.supersteve.api.javassist.util.HotSwapAgent.createAgentJarFile("hotswap.jar")
 * </pre>
 * <p>
 * Then, run the JVM with the VM argument {@code -javaagent:hotswap.jar} to deploy the hotswap agent.
 * </p>
 * <p>
 * If the {@code -javaagent} option is not given to the JVM, {@code HotSwapAgent} attempts to automatically create and start the hotswap agent on demand. This automated deployment may fail. If it fails, manually create the hotswap agent and deploy it by {@code -javaagent}.
 * </p>
 * <p>
 * The {@code HotSwapAgent} requires {@code tools.jar} as well as {@code plz.lizi.supersteve.api.javassist.jar}.
 * </p>
 * <p>
 * The idea of this class was given by <a href="https://github.com/alugowski">Adam Lugowski</a>. Shigeru Chiba wrote this class by referring to his <a href="https://github.com/turn/RedefineClassAgent">{@code RedefineClassAgent}</a>. For details, see <a href="https://github.com/jboss-plz/lizi/supersteve/api/plz/lizi/supersteve/api/javassist/plz/lizi/supersteve/api/plz/lizi/supersteve/api/javassist/issues/119">this discussion</a>.
 * </p>
 *
 * @see #redefine(Class, CtClass)
 * @see #redefine(Class[], CtClass[])
 * @since 3.22
 */
public class HotSwapAgent {
    private static volatile Instrumentation instrumentation = null;
    private static final Map<Class<?>, byte[]> CLASS_FILES = new HashMap<>();

    public static interface CtTransformCallBack {
        CtClass transform(Class<?> classBeingRedefined, byte[] classFileBuffer) throws Throwable;
    }

    /**
     * Redefines a class.
     */
    public static void redefine(Class<?> oldClass, CtClass newClass)
            throws RuntimeException, IOException {
        Class<?>[] old = { oldClass };
        CtClass[] newClasses = { newClass };
        redefine(old, newClasses);
    }

    public static void redefine(Class<?> oldClass, CtTransformCallBack callBack)
            throws Throwable {
        startAgent();
        ClassFileTransformer transformer = new ClassFileTransformer() {
            @Override
            public byte[] transform(ClassLoader loader, String className, Class<?> classBeingRedefined, ProtectionDomain protectionDomain, byte[] classfileBuffer) throws IllegalClassFormatException {
                try {
                    return callBack.transform(classBeingRedefined, classfileBuffer).toBytecode();
                } catch (Throwable e) {
                    throw new RuntimeException(e);
                }
            }

            @Override
            public byte[] transform(Module module, ClassLoader loader, String className, Class<?> classBeingRedefined, ProtectionDomain protectionDomain, byte[] classfileBuffer) throws IllegalClassFormatException {
                return transform(loader, className, classBeingRedefined, protectionDomain, classfileBuffer);
            }
        };
        long klass = PLZBase.UNSAFE.getLong(oldClass, 16);
        int accessflags = PLZBase.UNSAFE.getInt(klass + 164);
        PLZBase.UNSAFE.putInt(klass + 164, accessflags & ~0x04000000);
        instrumentation.addTransformer(transformer, true);
        Throwable t = null;
        try {
            retransform(oldClass);
        } catch (Throwable e2) {
            t = e2;
        }
        instrumentation.removeTransformer(transformer);
        PLZBase.UNSAFE.putInt(klass + 164, accessflags);
        if (t != null) {
            PLZBase.throwEx(t);
        }
    }

    public static synchronized void retransform(Class<?> clazz) throws Exception {
        instrumentation.retransformClasses(clazz);
    }

    /**
     * Redefines classes.
     */
    public static void redefine(Class<?>[] oldClasses, CtClass[] newClasses)
            throws RuntimeException, IOException {
        startAgent();
        ClassFileTransformer transformer = new ClassFileTransformer() {
            @Override
            public byte[] transform(ClassLoader loader, String className, Class<?> classBeingRedefined, ProtectionDomain protectionDomain, byte[] classfileBuffer) throws IllegalClassFormatException {
                for (int i = 0; i < oldClasses.length; i++) {
                    if (oldClasses[i] == classBeingRedefined) {
                        try {
                            return newClasses[i].toBytecode();
                        } catch (Throwable e) {
                            throw new RuntimeException(e);
                        }
                    }
                }
                return null;
            }

            @Override
            public byte[] transform(Module module, ClassLoader loader, String className, Class<?> classBeingRedefined, ProtectionDomain protectionDomain, byte[] classfileBuffer) throws IllegalClassFormatException {
                return transform(loader, className, classBeingRedefined, protectionDomain, classfileBuffer);
            }
        };
        instrumentation.addTransformer(transformer, true);
        Throwable t = null;
        try {
            instrumentation.retransformClasses(oldClasses);
        } catch (Throwable e) {
            t = e;
        }
        instrumentation.removeTransformer(transformer);
        if (t != null) {
            throw new RuntimeException(t);
        }
    }

    /**
     * Ensures that the agent is ready. It attempts to dynamically start the agent if necessary.
     */
    public static void startAgent() throws RuntimeException {
        if (instrumentation != null)
            return;
        try {
            File agentJar = createJarFile();
            PLZBase.defineClassInPackage(ClassLoader.getSystemClassLoader(), HotSwapAgent.class, HotSwapAgentInst.class.getName());
            PLZBase.invoke(Class.forName("sun.instrument.InstrumentationImpl"), "loadAgent0", agentJar.getAbsolutePath());
        } catch (Throwable e) {
            throw new RuntimeException("hotswap agent", e);
        }
        long last = System.currentTimeMillis();
        while (instrumentation == null) {
            if (System.currentTimeMillis() - last > 1000) {
                throw new RuntimeException("hotswap agent (timeout)");
            }
        }
        instrumentation.addTransformer(new ClassFileTransformer() {
            @Override
            public byte[] transform(ClassLoader loader, String className, Class<?> classBeingRedefined, ProtectionDomain protectionDomain, byte[] classfileBuffer) throws IllegalClassFormatException {
                if (classBeingRedefined != null && CLASS_FILES.containsKey(classBeingRedefined))
                    CLASS_FILES.putIfAbsent(classBeingRedefined, classfileBuffer.clone());
                return classfileBuffer;
            }
        }, true);
    }

    public static byte[] getBytes(Class<?> clazz) {
        if (!CLASS_FILES.containsKey(clazz)) {
            CLASS_FILES.put(clazz, null);
        }
        long klass = PLZBase.UNSAFE.getLong(clazz, 16);
        int accessflags = PLZBase.UNSAFE.getInt(klass + 164);
        accessflags = accessflags & ~0x04000000;
        PLZBase.UNSAFE.putInt(klass + 164, accessflags & ~0x04000000);
        try {
            retransform(clazz);
        } catch (Throwable e2) {
        } finally {
            PLZBase.UNSAFE.putInt(klass + 164, accessflags);
        }
        return CLASS_FILES.remove(clazz);
    }

    /**
     * Creates an agent file for using {@code HotSwapAgent}.
     */
    public static File createAgentJarFile(String fileName)
            throws IOException, RuntimeException {
        return createJarFile(new File(fileName));
    }

    private static File createJarFile()
            throws IOException, RuntimeException {
        File jar = File.createTempFile("agent", ".jar");
        jar.deleteOnExit();
        return createJarFile(jar);
    }

    private static File createJarFile(File jar)
            throws IOException {
        Manifest manifest = new Manifest();
        Attributes attrs = manifest.getMainAttributes();
        attrs.put(Attributes.Name.MANIFEST_VERSION, "1.0");
        attrs.put(new Attributes.Name("Premain-Class"), HotSwapAgentInst.class.getName());
        attrs.put(new Attributes.Name("Agent-Class"), HotSwapAgentInst.class.getName());
        attrs.put(new Attributes.Name("Launcher-Agent-Class"), HotSwapAgentInst.class.getName());
        attrs.put(new Attributes.Name("Can-Retransform-Classes"), "true");
        attrs.put(new Attributes.Name("Can-Redefine-Classes"), "true");
        JarOutputStream jos = null;
        try {
            jos = new JarOutputStream(new FileOutputStream(jar), manifest);
            String cname = HotSwapAgentInst.class.getName();
            JarEntry e = new JarEntry(cname.replace('.', '/') + ".class");
            jos.putNextEntry(e);
            ClassPool pool = ClassPool.getDefault();
            CtClass clazz = pool.get(cname);
            jos.write(clazz.toBytecode());
            jos.closeEntry();
        } catch (Throwable t) {
        } finally {
            if (jos != null)
                jos.close();
        }
        return jar;
    }
}
