package plz.lizi.supersteve.network;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import plz.lizi.supersteve.api.FloatObf;
import plz.lizi.supersteve.entity.SuperSteveEntityBase;
import plz.lizi.supersteve.entity.SuperSteveEntityBase.SSMode;

public class SSData {
    public float[] health = new float[1];
    public SuperSteveEntityBase.SSMode mode = SSMode.NORMAL;
    public int tick = 0;

    public SSData() {}

    public SSData(FriendlyByteBuf buf) {
        health[0] = buf.readFloat();
        mode = SSMode.valueOf(buf.readUtf());
        tick = buf.readInt();
    }

    public void write(FriendlyByteBuf buf) {
        buf.writeFloat(health[0]);
        buf.writeUtf(mode.name());
        buf.writeInt(tick);
    }

    public void save(CompoundTag tag) {
        tag.putString("SSH", FloatObf.enc(health[0]));
        tag.putString("SSM", mode.name());
        tag.putInt("SST", tick);
    }

    public SSData load(CompoundTag tag) {
        if (tag.contains("SSH"))
            health[0] = FloatObf.dec(tag.getString("SSH"))[0];
        if (tag.contains("SSM"))
            mode = SSMode.valueOf(tag.getString("SSM"));
        if (tag.contains("SST"))
            tick = tag.getInt("SST");
        return this;
    }
}
