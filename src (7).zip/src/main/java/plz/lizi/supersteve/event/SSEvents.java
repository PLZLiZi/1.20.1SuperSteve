package plz.lizi.supersteve.event;

import java.awt.Color;
import org.joml.Matrix4f;
import com.mojang.blaze3d.platform.Window;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.blaze3d.vertex.VertexFormat.Mode;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.LerpingBossEvent;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.RenderStateShard;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.MultiBufferSource.BufferSource;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraftforge.client.event.CustomizeGuiOverlayEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import plz.lizi.supersteve.SuperSteveMod;
import plz.lizi.supersteve.api.SSUtil;
import plz.lizi.supersteve.entity.SuperSteveEntityBase;

public class SSEvents {
	public static ResourceLocation SS_BAR = ResourceLocation.tryBuild(SuperSteveMod.MODID, "textures/gui/ssbar.png");

	@SubscribeEvent
	public static void bartest(CustomizeGuiOverlayEvent.BossEventProgress event) {
		LerpingBossEvent bossEvent = event.getBossEvent();
		Entity entity = Minecraft.getInstance().level.getEntities().get(bossEvent.getId());
		if (entity instanceof SuperSteveEntityBase ss) {
			event.setCanceled(true);
			Minecraft mc = Minecraft.getInstance();
			Window window = mc.getWindow();
			RenderSystem.enableBlend();
			GuiGraphics guiGraphics = event.getGuiGraphics();
			float x = window.getGuiScaledWidth() / 2;
			float y = event.getY();
			float barWidth = 180;
			float barHeight = 22;
			float progress = bossEvent.getProgress();
			if (progress > 0) {
				Matrix4f pose = guiGraphics.pose().last().pose();
				BufferBuilder builder = Tesselator.getInstance().getBuilder();
				builder.begin(Mode.QUADS, DefaultVertexFormat.POSITION_TEX);
				float xStart = x - barWidth / 2F + 10F;
				float yStart = y - barHeight / 2F + 9F;
				builder.vertex(pose, x - barWidth / 2F, y - barHeight / 2F, 0).uv(0, 0).endVertex();
				builder.vertex(pose, x - barWidth / 2F, y + barHeight / 2F, 0).uv(0, 22F / 27F).endVertex();
				builder.vertex(pose, x + barWidth / 2F, y + barHeight / 2F, 0).uv(1, 22F / 27F).endVertex();
				builder.vertex(pose, x + barWidth / 2F, y - barHeight / 2F, 0).uv(1, 0).endVertex();
				RenderSystem.setShader(GameRenderer::getPositionTexShader);
				RenderSystem.setShaderTexture(0, SS_BAR);
				RenderStateShard.TRANSLUCENT_TRANSPARENCY.setupRenderState();
				BufferUploader.drawWithShader(builder.end());
				builder.begin(Mode.QUADS, DefaultVertexFormat.POSITION_TEX);
				float hWidth = 165;
				float hHeight = 5;
				builder.vertex(pose, xStart, yStart, 0).uv(0, 22F / 27F).endVertex();
				builder.vertex(pose, xStart, yStart + hHeight, 0).uv(0, 1).endVertex();
				builder.vertex(pose, xStart + (progress * hWidth), yStart + hHeight, 0).uv(165F / 180F * progress, 1).endVertex();
				builder.vertex(pose, xStart + (progress * hWidth), yStart, 0).uv(165F / 180F * progress, 22F / 27F).endVertex();
				BufferUploader.drawWithShader(builder.end());
				RenderStateShard.TRANSLUCENT_TRANSPARENCY.clearRenderState();
			}
			String bossName = bossEvent.getName().getString();
			guiGraphics.drawCenteredString(mc.font, bossName, (int)x, (int)(y - barHeight / 2F), Color.HSBtoRGB(SSUtil.getRainbowHue(3000), 1, 1));
			RenderSystem.disableBlend();
		}
	}

	public static int rgba(int red, int green, int blue, int alpha) {
		alpha %= 256;
		red %= 256;
		green %= 256;
		blue %= 256;
		return alpha << 24 | red << 16 | green << 8 | blue;
	}
}
