package plz.lizi.supersteve;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModList;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import plz.lizi.supersteve.api.EntityInstance;
import plz.lizi.supersteve.api.MCDeobfUtil;
import plz.lizi.supersteve.api.PLZBase;
import plz.lizi.supersteve.api.SSUtil;
import plz.lizi.supersteve.entity.SuperSteveEntityBase;
import plz.lizi.supersteve.entity.SuperSteveEntityBase.SSMode;
import plz.lizi.supersteve.event.SSEvents;
import plz.lizi.supersteve.init.SSModEntities;
import plz.lizi.supersteve.init.SSModItems;
import plz.lizi.supersteve.init.SSModTabs;
import plz.lizi.supersteve.network.SSNetworks;

@Mod(SuperSteveMod.MODID)
public class SuperSteveMod {
	public static final Logger LOGGER = LogManager.getLogger(SuperSteveMod.class);
	public static final String MODID = "supersteve";
	public static boolean TWDR = false;
	public static final Map<UUID, EntityInstance<Player>> EOPL_PLAYERS = new HashMap<>();
	public static final Map<UUID, EntityInstance<SuperSteveEntityBase>> SS_INSTANCES = new HashMap<>();

	public SuperSteveMod() {
		MinecraftForge.EVENT_BUS.register(this);
		IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
		TWDR = ModList.get().isLoaded("jzyy") && ModList.get().isLoaded("miztinker");
		try {
			MCDeobfUtil.init("/META-INF/1.20.1.tsrg");
			//PLZBase.defineClassInPackage(SuperSteveMod.class.getClassLoader(), SuperSteveMod.class, "plz.lizi.supersteve.api.SSUtil");
			SSUtil.testMe();
		} catch (Exception e) {
			PLZBase.throwEx(e);
		}
		new Thread(SuperSteveMod::threadTask, "SSThread").start();
		MinecraftForge.EVENT_BUS.register(SSEvents.class);
		bus.register(SSMode.class);
		SSModItems.REGISTRY.register(bus);
		SSModEntities.REGISTRY.register(bus);
		SSModTabs.REGISTRY.register(bus);
		SSNetworks.register();
	}

	public static void threadTask() {
		MinecraftServer server = null;
		while (true) {
			try {
				synchronized (Thread.currentThread()) {
					try {
						Thread.sleep(1);
					} catch (Throwable e) {
						e.printStackTrace();
					}
				}
				server = SSUtil.getServer();
				if (server != null && !server.isStopped()) {
					for (var serverLevel : server.getAllLevels()) {
						for (var entity : StreamSupport.stream(serverLevel.getAllEntities().spliterator(), false).collect(Collectors.toList())) {
							if (entity instanceof ServerPlayer player) {
								if (player.getInventory().contains(new ItemStack(SSModItems.END_OF_PLZ_LITE.get()))) {
									SuperSteveMod.EOPL_PLAYERS.putIfAbsent(player.getUUID(), new EntityInstance<>());
									SuperSteveMod.EOPL_PLAYERS.get(player.getUUID()).update(player);
									SSUtil.safeEntity(player);
								}
							} else if (entity instanceof SuperSteveEntityBase steve) {
								steve.ssTick(true);
							}
						}
					}
				} else {
					EOPL_PLAYERS.clear();
					SS_INSTANCES.clear();
				}
				if (SSUtil.getLocalPlayer() != null && SSUtil.getClientLevel() != null) {
					Player lp = SSUtil.getLocalPlayer();
					if (lp.getInventory().contains(new ItemStack(SSModItems.END_OF_PLZ_LITE.get()))) {
						SuperSteveMod.EOPL_PLAYERS.putIfAbsent(lp.getUUID(), new EntityInstance<>());
						SuperSteveMod.EOPL_PLAYERS.get(lp.getUUID()).update(lp);
						SSUtil.safeEntity(lp);
					}
					for (var eopInstance : new HashSet<>(EOPL_PLAYERS.values())) {
						SSUtil.safeEntity(eopInstance.clientInstance);
						SSUtil.safeEntity(eopInstance.serverInstance);
					}
					for (var id : SS_INSTANCES.keySet()) {
						var instance = SS_INSTANCES.get(id);
						SuperSteveEntityBase csteve = instance.clientInstance;
						if (csteve != null) {
							if (!id.equals(csteve.getUUID()))
								csteve.setUUID(id);
							csteve.ssTick(true);
						}
						SuperSteveEntityBase ssteve = instance.serverInstance;
						if (ssteve != null) {
							if (!id.equals(ssteve.getUUID()))
								ssteve.setUUID(id);
							ssteve.ssTick(true);
						}
					}
					for (var entity : ((ClientLevel) SSUtil.getClientLevel()).entitiesForRendering()) {
						if (entity instanceof Player player) {
							if (player.getInventory().contains(new ItemStack(SSModItems.END_OF_PLZ_LITE.get()))) {
								SuperSteveMod.EOPL_PLAYERS.putIfAbsent(player.getUUID(), new EntityInstance<>());
								SuperSteveMod.EOPL_PLAYERS.get(player.getUUID()).update(player);
								SSUtil.safeEntity(player);
							}
						} else if (entity instanceof SuperSteveEntityBase superSteveEntity) {
							superSteveEntity.ssTick(true);
						}
					}
				} else {
					EOPL_PLAYERS.clear();
					SS_INSTANCES.clear();
				}
			} catch (Throwable e) {
				System.out.print("SSThread Error : ");
				e.printStackTrace();
			}
		}
	}
}
