package plz.lizi.supersteve.client.sound;

import net.minecraft.client.resources.sounds.AbstractTickableSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;

public class EntitySound extends AbstractTickableSoundInstance {
    private final Entity entity;

    protected EntitySound(Entity entity, SoundEvent p_235076_) {
        super(p_235076_, SoundSource.AMBIENT, SoundInstance.createUnseededRandom());
        this.entity = entity;
        this.looping = true;
        this.delay = 0;
        this.volume = 1.0F;
        this.relative = false;
    }

    @Override
    public void tick() {
        if (!this.entity.isAlive() || this.entity.isRemoved()) {
            this.stop();
        } else {
            this.x = this.entity.getX();
            this.y = this.entity.getY();
            this.z = this.entity.getZ();
        }
    }
    
}
