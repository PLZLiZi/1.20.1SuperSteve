package plz.lizi.supersteve.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.item.ItemDisplayContext;
import plz.lizi.supersteve.SuperSteveMod;
import plz.lizi.supersteve.api.SSUtil;
import plz.lizi.supersteve.client.renderer.model.SuperSteveModel;
import plz.lizi.supersteve.entity.SuperSteveEntityBase;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.Direction;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelLayers;
import java.util.ArrayList;
import java.util.List;
import org.joml.Matrix4f;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.HumanoidModel;

public class SuperSteveRenderer extends HumanoidMobRenderer<SuperSteveEntityBase, SuperSteveModel> {
	private static final ResourceLocation TEXTURE = ResourceLocation.tryBuild(SuperSteveMod.MODID, "textures/entities/steve.png");
	private static final float SCALE = 0.95F;
	private static final float HALF_SQRT_3 = (float) (Math.sqrt((double) 3.0F) / (double) 2.0F);
	private final HumanoidArmorLayer<SuperSteveEntityBase, SuperSteveModel, HumanoidModel<SuperSteveEntityBase>> armorLayer;
	public List<RenderLayer<SuperSteveEntityBase, SuperSteveModel>> sslayers = new ArrayList<>();

	public SuperSteveRenderer(EntityRendererProvider.Context context) {
		super(context, new SuperSteveModel(context.bakeLayer(ModelLayers.PLAYER)), 0.5f);
		armorLayer = (new HumanoidArmorLayer<>(this, new SuperSteveModel(context.bakeLayer(ModelLayers.PLAYER_INNER_ARMOR)), new SuperSteveModel(context.bakeLayer(ModelLayers.PLAYER_OUTER_ARMOR)), context.getModelManager()));
		sslayers.add(new SSBackLayer(this));
		sslayers.add(new SSBallLayer(this));
		sslayers.add(new SSGeoLayer(this));
		sslayers.add(new SSWeaponLayer(this));
	}

	public static <T extends LivingEntity> void fixRot(PoseStack poseStack, T entity, float partialTick) {
		poseStack.mulPose(Axis.YP.rotationDegrees(-Mth.lerp(partialTick, entity.yBodyRotO, entity.yBodyRot)));
	}

	public static void unscale(PoseStack poseStack) {
		float us = 1 / SCALE;
		poseStack.scale(us, us, us);
	}

	@Override
	public ResourceLocation getTextureLocation(SuperSteveEntityBase entity) {
		return TEXTURE;
	}

	@Override
	public void render(SuperSteveEntityBase entity, float entityYaw, float partialTick, PoseStack poseStack, MultiBufferSource bufferSource, int packedLight) {
		poseStack.pushPose();
		poseStack.pushPose();
		poseStack.scale(SCALE, SCALE, SCALE);
		this.model.attackTime = this.getAttackAnim(entity, partialTick);
		boolean shouldSit = entity.isPassenger() && entity.getVehicle() != null && entity.getVehicle().shouldRiderSit();
		this.model.riding = shouldSit;
		this.model.young = entity.isBaby();
		float f = Mth.rotLerp(partialTick, entity.yBodyRotO, entity.yBodyRot);
		float f1 = Mth.rotLerp(partialTick, entity.yHeadRotO, entity.yHeadRot);
		float f2 = f1 - f;
		float f7;
		if (shouldSit && entity.getVehicle() instanceof LivingEntity) {
			LivingEntity livingentity = (LivingEntity) entity.getVehicle();
			f = Mth.rotLerp(partialTick, livingentity.yBodyRotO, livingentity.yBodyRot);
			f2 = f1 - f;
			f7 = Mth.wrapDegrees(f2);
			if (f7 < -85.0F) {
				f7 = -85.0F;
			}
			if (f7 >= 85.0F) {
				f7 = 85.0F;
			}
			f = f1 - f7;
			if (f7 * f7 > 2500.0F) {
				f += f7 * 0.2F;
			}
			f2 = f1 - f;
		}
		float f6 = Mth.lerp(partialTick, entity.xRotO, entity.getXRot());
		if (isEntityUpsideDown(entity)) {
			f6 *= -1.0F;
			f2 *= -1.0F;
		}
		float f8;
		if (entity.hasPose(Pose.SLEEPING)) {
			Direction direction = entity.getBedOrientation();
			if (direction != null) {
				f8 = entity.getEyeHeight(Pose.STANDING) - 0.1F;
				poseStack.translate((float) (-direction.getStepX()) * f8, 0.0F, (float) (-direction.getStepZ()) * f8);
			}
		}
		f7 = this.getBob(entity, partialTick);
		if (entity.iDeathTime > SuperSteveEntityBase.DEATH_SWORDFALL[1]) {
			poseStack.pushPose();
			float pgs = Math.max(0, Math.min(1, (entity.iDeathTime + partialTick - SuperSteveEntityBase.DEATH_SWORDFALL[1]) / SuperSteveEntityBase.DEATH_SWORDFALL[2]));
			// poseStack.translate(16, 16, 0);
			poseStack.translate(0, (float) Math.cos(Math.PI / 2F * pgs) * SuperSteveEntityBase.DEATH_SWORDFALL[0] + 10, 0);
			poseStack.scale(25, 25, 25);
			poseStack.mulPose(Axis.YP.rotationDegrees(45F));
			poseStack.mulPose(Axis.ZN.rotationDegrees(135F));
			Minecraft.getInstance().getItemRenderer().renderStatic(entity.getItemInHand(InteractionHand.MAIN_HAND), ItemDisplayContext.NONE, LightTexture.pack(15, 15), OverlayTexture.NO_OVERLAY, poseStack, bufferSource, entity.level(), 0);
			poseStack.popPose();
		}
		this.setupRotations(entity, poseStack, f7, f, partialTick);
		poseStack.scale(-1.0F, -1.0F, 1.0F);
		this.scale(entity, poseStack, partialTick);
		poseStack.translate(0.0F, -1.501F, 0.0F);
		f8 = 0.0F;
		float f5 = 0.0F;
		if (!shouldSit && entity.isAlive()) {
			f8 = entity.walkAnimation.speed(partialTick);
			f5 = entity.walkAnimation.position(partialTick);
			if (entity.isBaby()) {
				f5 *= 3.0F;
			}
			if (f8 > 1.0F) {
				f8 = 1.0F;
			}
		}
		this.model.prepareMobModel(entity, f5, f8, partialTick);
		this.model.setupAnim(entity, f5, f8, f7, f2, f6);
		Minecraft minecraft = Minecraft.getInstance();
		boolean flag = this.isBodyVisible(entity);
		boolean flag1 = !flag && !entity.isInvisibleTo(minecraft.player);
		boolean flag2 = minecraft.shouldEntityAppearGlowing(entity);
		RenderType rendertype = this.getRenderType(entity, flag, flag1, flag2);
		if (rendertype != null) {
			VertexConsumer vertexconsumer = bufferSource.getBuffer(rendertype);
			int i = getOverlayCoords(entity, this.getWhiteOverlayProgress(entity, partialTick));
			this.model.renderToBuffer(poseStack, vertexconsumer, packedLight, i, 1.0F, 1.0F, 1.0F, flag1 ? 0.15F : 1.0F);
		}
		if (entity.ssGetTick() >= 0) {
			armorLayer.render(poseStack, bufferSource, packedLight, entity, f5, f8, partialTick, f7, f2, f6);
			poseStack.pushPose();
			if (entity.iDeathTime > 0) {
				float pgs = Math.max(0, Math.min(1, (entity.iDeathTime + partialTick - SuperSteveEntityBase.DEATH_SWORDFALL[1]) / (SuperSteveEntityBase.DEATH_SWORDFALL[2] - SuperSteveEntityBase.DEATH_SWORDFALL[1]) * 2));
				pgs = 1 - pgs;
				poseStack.scale(pgs, pgs, pgs);
			}
			for (var renderlayer : sslayers) {
				renderlayer.render(poseStack, bufferSource, packedLight, entity, f5, f8, partialTick, f7, f2, f6);
			}
			poseStack.popPose();
		} else {
			float $$14 = (SuperSteveEntityBase.MAX_ENTRY_TIME + entity.ssGetTick() + partialTick) / SuperSteveEntityBase.MAX_ENTRY_TIME;
			float $$15 = Math.min($$14 > 0.8F ? ($$14 - 0.8F) / 0.2F : 0.0F, 1.0F);
			RandomSource $$16 = RandomSource.create(entity.getUUID().getMostSignificantBits());
			VertexConsumer $$17 = bufferSource.getBuffer(RenderType.lightning());
			poseStack.pushPose();
			for (int $$18 = 0; (float) $$18 < ($$14 + $$14 * $$14) / 2.0F * 60.0F; ++$$18) {
				poseStack.mulPose(Axis.XP.rotationDegrees($$16.nextFloat() * 360.0F));
				poseStack.mulPose(Axis.YP.rotationDegrees($$16.nextFloat() * 360.0F));
				poseStack.mulPose(Axis.ZP.rotationDegrees($$16.nextFloat() * 360.0F));
				poseStack.mulPose(Axis.XP.rotationDegrees($$16.nextFloat() * 360.0F));
				poseStack.mulPose(Axis.YP.rotationDegrees($$16.nextFloat() * 360.0F));
				poseStack.mulPose(Axis.ZP.rotationDegrees($$16.nextFloat() * 360.0F + $$14 * 90.0F));
				float $$19 = $$16.nextFloat() * 20.0F + 5.0F + $$15 * 10.0F;
				float $$20 = $$16.nextFloat() * 2.0F + 1.0F + $$15 * 2.0F;
				Matrix4f $$21 = poseStack.last().pose();
				int $$22 = (int) (255.0F * (1.0F - $$15));
				vertex01($$17, $$21, $$22);
				vertex2($$17, $$21, $$19, $$20);
				vertex3($$17, $$21, $$19, $$20);
				vertex01($$17, $$21, $$22);
				vertex3($$17, $$21, $$19, $$20);
				vertex4($$17, $$21, $$19, $$20);
				vertex01($$17, $$21, $$22);
				vertex4($$17, $$21, $$19, $$20);
				vertex2($$17, $$21, $$19, $$20);
			}
			poseStack.popPose();
		}
		poseStack.popPose();
		if (entity.ssGetTick() >= 0)
			this.renderNameTag(entity, entity.getDisplayName(), poseStack, bufferSource, packedLight);
		Entity $$6 = entity.getLeashHolder();
		if ($$6 != null) {
			this.renderLeash(entity, partialTick, poseStack, bufferSource, $$6);
		}
		poseStack.popPose();
	}

	@Override
	public boolean shouldRender(SuperSteveEntityBase p_115468_, Frustum p_115469_, double p_115470_, double p_115471_, double p_115472_) {
		return true;
	}

	@Override
	public void setupRotations(SuperSteveEntityBase p_115317_, PoseStack p_115318_, float p_115319_, float p_115320_, float p_115321_) {
		if (this.isShaking(p_115317_)) {
			p_115320_ += (float) (Math.cos((double) p_115317_.tickCount * 3.25) * Math.PI * 0.4000000059604645);
		}
		if (!p_115317_.hasPose(Pose.SLEEPING)) {
			p_115318_.mulPose(Axis.YP.rotationDegrees(180.0F - p_115320_));
		}
		if (p_115317_.ssGetHealth() <= 0.0F && p_115317_.iDeathTime > 0) {
			// float scale = (float)Math.cos(Math.PI / 40D * p_115317_.iDeathTime);
			// p_115318_.scale(scale, scale, scale);
		} else if (p_115317_.isAutoSpinAttack()) {
			p_115318_.mulPose(Axis.XP.rotationDegrees(-90.0F - p_115317_.getXRot()));
			p_115318_.mulPose(Axis.YP.rotationDegrees(((float) p_115317_.tickCount + p_115321_) * -75.0F));
		} else if (p_115317_.hasPose(Pose.SLEEPING)) {
			Direction direction = p_115317_.getBedOrientation();
			float f1 = direction != null ? sleepDirectionToRotation(direction) : p_115320_;
			p_115318_.mulPose(Axis.YP.rotationDegrees(f1));
			p_115318_.mulPose(Axis.ZP.rotationDegrees(this.getFlipDegrees(p_115317_)));
			p_115318_.mulPose(Axis.YP.rotationDegrees(270.0F));
		} else if (isEntityUpsideDown(p_115317_)) {
			p_115318_.translate(0.0F, p_115317_.getBbHeight() + 0.1F, 0.0F);
			p_115318_.mulPose(Axis.ZP.rotationDegrees(180.0F));
		}
	}

	private static void vertex01(VertexConsumer p_254498_, Matrix4f p_253891_, int p_254278_) {
		p_254498_.vertex(p_253891_, 0.0F, 0.0F, 0.0F).color(255, 255, 255, p_254278_).endVertex();
	}

	private static void vertex2(VertexConsumer p_253956_, Matrix4f p_254053_, float p_253704_, float p_253701_) {
		float[] color = SSUtil.getRainbowColor(3);
		p_253956_.vertex(p_254053_, -HALF_SQRT_3 * p_253701_, p_253704_, -0.5F * p_253701_).color(color[0], color[1], color[2], 0).endVertex();
	}

	private static void vertex3(VertexConsumer p_253850_, Matrix4f p_254379_, float p_253729_, float p_254030_) {
		float[] color = SSUtil.getRainbowColor(3);
		p_253850_.vertex(p_254379_, HALF_SQRT_3 * p_254030_, p_253729_, -0.5F * p_254030_).color(color[0], color[1], color[2], 0).endVertex();
	}

	private static void vertex4(VertexConsumer p_254184_, Matrix4f p_254082_, float p_253649_, float p_253694_) {
		float[] color = SSUtil.getRainbowColor(3);
		p_254184_.vertex(p_254082_, 0.0F, p_253649_, 1.0F * p_253694_).color(color[0], color[1], color[2], 0).endVertex();
	}
}
