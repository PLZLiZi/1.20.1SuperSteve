package plz.lizi.supersteve.entity;

import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.Level;
import plz.lizi.supersteve.level.SSBossEvent;

public abstract class SuperSteveEntityBase extends PathfinderMob {
	public static enum SSMode {
		NORMAL, PLZLIZI
	}

	public static final float ATTACK_RANGE = 4F;
	public static final int MAX_ENTRY_TIME = 100;
	public static final int MAX_DEATH_TIME = 100;
	public static final int[] DEATH_SWORDFALL = new int[] { 100, 0, 50 };
	public static final EntityDataAccessor<String> DATA_SS_HEALTH_ID = SynchedEntityData.defineId(SuperSteveEntityBase.class, EntityDataSerializers.STRING);
	public static final EntityDataAccessor<String> DATA_SS_TYPE_ID = SynchedEntityData.defineId(SuperSteveEntityBase.class, EntityDataSerializers.STRING);
	public static final EntityDataAccessor<Integer> DATA_SS_TICK_ID = SynchedEntityData.defineId(SuperSteveEntityBase.class, EntityDataSerializers.INT);
	public int iInvulnerableTime = 0;
	public int iDeathTime = 0;
	public SSBossEvent bossEvent;

	protected SuperSteveEntityBase(EntityType<? extends PathfinderMob> p_21683_, Level p_21684_) {
		super(p_21683_, p_21684_);
	}

	public static AttributeSupplier.Builder createAttributes() {
		AttributeSupplier.Builder builder = Mob.createMobAttributes();
		builder = builder.add(Attributes.MOVEMENT_SPEED, 0.5);
		builder = builder.add(Attributes.MAX_HEALTH, 20);
		builder = builder.add(Attributes.ARMOR, 32767);
		builder = builder.add(Attributes.ATTACK_DAMAGE, 32767);
		builder = builder.add(Attributes.FOLLOW_RANGE, 2048);
		builder = builder.add(Attributes.KNOCKBACK_RESISTANCE, 32767);
		builder = builder.add(Attributes.ATTACK_KNOCKBACK, 0);
		return builder;
	}

	public abstract void ssTick(boolean inOtherThread);

	public abstract void ssSetHealth(float health, Object zhis);

	public abstract float ssGetHealth();

	public abstract SSMode ssGetMode();

	public abstract void ssSetMode(SSMode mode);

	public abstract int ssGetTick();

	public abstract float ssGetAttR(boolean renderfix);
}
