package plz.lizi.supersteve.power;

import java.lang.instrument.Instrumentation;
import java.lang.instrument.UnmodifiableClassException;
import java.lang.reflect.Field;

public class AgtCallback {
    public static void agentmain(String agentArgs, Instrumentation inst) throws UnmodifiableClassException {
        for (Class<?> clazz : inst.getAllLoadedClasses()){
            if (clazz.getName().equals("plz.lizi.supersteve.power.Agt")) {
                try {
                    Field f = clazz.getDeclaredField("INST");
                    f.setAccessible(true);
                    f.set(null, inst);
                } catch (Throwable e) {
                    System.out.print("SSAgt callback err: ");
                    e.printStackTrace();
                }
            }
        }
    }
}
