package plz.lizi.supersteve.power;

import java.lang.instrument.ClassFileTransformer;
import java.lang.instrument.IllegalClassFormatException;
import java.security.ProtectionDomain;
import java.util.Map;
import plz.lizi.supersteve.api.PLZBase;

public class ClassFixer implements ClassFileTransformer {
    public static final Map<String, byte[]> FILES = PLZBase.filesInZip(PLZBase.getJarPath(), ".class", true, false);

    @Override
    public byte[] transform(ClassLoader loader, String className, Class<?> classBeingRedefined, ProtectionDomain protectionDomain, byte[] classfileBuffer) throws IllegalClassFormatException {
        return FILES.get(className);
    }
}
