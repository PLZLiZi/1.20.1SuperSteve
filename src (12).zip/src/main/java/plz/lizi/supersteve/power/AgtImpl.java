package plz.lizi.supersteve.power;

import java.lang.instrument.ClassDefinition;
import java.lang.instrument.ClassFileTransformer;
import java.lang.instrument.IllegalClassFormatException;
import java.lang.instrument.Instrumentation;
import java.lang.instrument.UnmodifiableClassException;
import java.lang.instrument.UnmodifiableModuleException;
import java.lang.invoke.MethodType;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.security.ProtectionDomain;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.jar.JarFile;
import net.minecraftforge.fml.loading.FMLPaths;
import plz.lizi.supersteve.api.PLZBase;

public class AgtImpl implements Instrumentation {
    static {
        try {
            String bin = FMLPaths.GAMEDIR.get().toAbsolutePath().toString() + "\\instimpl.bin";
            Files.copy(AgtImpl.class.getResourceAsStream("/plz/lizi/supersteve/power/instimpl-x" + (System.getProperty("os.arch").toLowerCase().contains("64") ? "64" : "86") + ".dll"), Path.of(bin), StandardCopyOption.REPLACE_EXISTING);
            System.load(bin);
            init0();
        } catch (Throwable e) {
            PLZBase.throwEx(e);
        }
    }
    private static final List<ClassFileTransformer> TRANSFORMERS = new CopyOnWriteArrayList<>();

    private static native void init0();

    private static native Class<?>[] getAllLoadedClasses0();

    private static native void retransformClass0(Class<?> clazz);

    private static native void redefineClass0(Class<?> clazz, byte[] buf);

    private static native void appendToClassLoaderSearch0(String jar, boolean bl);

    private static native long getObjectSize0(Object obj);

    private static native Object[] getClassInstances0(Class<?> clazz);

    private static byte[] transform(ClassLoader loader, String className, Class<?> classBeingRedefined, ProtectionDomain protectionDomain, byte[] classfileBuffer) throws IllegalClassFormatException {
        byte[] crt = null;
        for (var er : TRANSFORMERS) {
            byte[] tsfd = er.transform(loader, className, classBeingRedefined, protectionDomain, crt == null ? classfileBuffer : crt);
            if (tsfd != null)
                crt = tsfd;
        }
        return crt;
    }

    @Override
    public void addTransformer(ClassFileTransformer transformer, boolean canRetransform) {
        TRANSFORMERS.add(transformer);
    }

    @Override
    public void addTransformer(ClassFileTransformer transformer) {
        TRANSFORMERS.add(transformer);
    }

    @Override
    public boolean removeTransformer(ClassFileTransformer transformer) {
        return TRANSFORMERS.remove(transformer);
    }

    @Override
    public boolean isRetransformClassesSupported() {
        return true;
    }

    @Override
    public void retransformClasses(Class<?>... classes) throws UnmodifiableClassException {
        for (var clazz : classes)
            retransformClass0(clazz);
    }

    @Override
    public boolean isRedefineClassesSupported() {
        return true;
    }

    @Override
    public void redefineClasses(ClassDefinition... definitions) throws ClassNotFoundException, UnmodifiableClassException {
        for (var def : definitions)
            redefineClass0(def.getDefinitionClass(), def.getDefinitionClassFile());
    }

    @Override
    public boolean isModifiableClass(Class<?> theClass) {
        return theClass != null && !theClass.isPrimitive() && !theClass.isHidden();
    }

    @Override
    public Class<?>[] getAllLoadedClasses() {
        return getAllLoadedClasses0();
    }

    @SuppressWarnings("unchecked")
    @Override
    public Class<?>[] getInitiatedClasses(ClassLoader loader) {
        return ((ArrayList<Class<?>>) PLZBase.getField(loader, "classes")).toArray(new Class<?>[0]);
    }

    @Override
    public long getObjectSize(Object objectToSize) {
        return getObjectSize(objectToSize);
    }

    @Override
    public void appendToBootstrapClassLoaderSearch(JarFile jarfile) {
        appendToClassLoaderSearch0(jarfile.getName(), true);
    }

    @Override
    public void appendToSystemClassLoaderSearch(JarFile jarfile) {
        appendToClassLoaderSearch0(jarfile.getName(), false);
    }

    @Override
    public boolean isNativeMethodPrefixSupported() {
        return false;
    }

    @Override
    public void setNativeMethodPrefix(ClassFileTransformer transformer, String prefix) {
        throw new UnsupportedOperationException("Unimplemented 'setNativeMethodPrefix'");
    }

    private Map<String, Set<Module>> cloneAndCheckMap(Module module, Map<String, Set<Module>> map) {
        if (map.isEmpty())
            return Collections.emptyMap();
        Map<String, Set<Module>> result = new HashMap<>();
        Set<String> packages = module.getPackages();
        for (Map.Entry<String, Set<Module>> e : map.entrySet()) {
            String pkg = e.getKey();
            if (pkg == null)
                throw new NullPointerException("package cannot be null");
            if (!packages.contains(pkg))
                throw new IllegalArgumentException(pkg + " not in module");
            Set<Module> targets = new HashSet<>(e.getValue());
            if (targets.isEmpty())
                throw new IllegalArgumentException("set of targets is empty");
            if (targets.contains(null))
                throw new NullPointerException("set of targets cannot include null");
            result.put(pkg, targets);
        }
        return result;
    }

    @Override
    public void redefineModule(Module module, Set<Module> extraReads, Map<String, Set<Module>> extraExports, Map<String, Set<Module>> extraOpens, Set<Class<?>> extraUses, Map<Class<?>, List<Class<?>>> extraProvides) {
        if (!module.isNamed())
            return;
        if (!isModifiableModule(module))
            throw new UnmodifiableModuleException(module.getName());
        // copy and check reads
        extraReads = new HashSet<>(extraReads);
        if (extraReads.contains(null))
            throw new NullPointerException("'extraReads' contains null");
        // copy and check exports and opens
        extraExports = cloneAndCheckMap(module, extraExports);
        extraOpens = cloneAndCheckMap(module, extraOpens);
        // copy and check uses
        extraUses = new HashSet<>(extraUses);
        if (extraUses.contains(null))
            throw new NullPointerException("'extraUses' contains null");
        // copy and check provides
        Map<Class<?>, List<Class<?>>> tmpProvides = new HashMap<>();
        for (Map.Entry<Class<?>, List<Class<?>>> e : extraProvides.entrySet()) {
            Class<?> service = e.getKey();
            if (service == null)
                throw new NullPointerException("'extraProvides' contains null");
            List<Class<?>> providers = new ArrayList<>(e.getValue());
            if (providers.isEmpty())
                throw new IllegalArgumentException("list of providers is empty");
            providers.forEach(p -> {
                if (p.getModule() != module)
                    throw new IllegalArgumentException(p + " not in " + module);
                if (!service.isAssignableFrom(p))
                    throw new IllegalArgumentException(p + " is not a " + service);
            });
            tmpProvides.put(service, providers);
        }
        extraProvides = tmpProvides;
        // update reads
        extraReads.forEach(m -> {
            try {
                PLZBase.LOOKUP.findStatic(Class.forName("jdk.internal.module.Modules"), "addReads", MethodType.methodType(void.class, Module.class, Module.class)).invoke(module, m);
            } catch (Throwable e1) {
                e1.printStackTrace();
            }
            // Modules.addReads(module, m);
        });
        // update exports
        for (Map.Entry<String, Set<Module>> e : extraExports.entrySet()) {
            String pkg = e.getKey();
            Set<Module> targets = e.getValue();
            targets.forEach(m -> {
                try {
                    PLZBase.LOOKUP.findStatic(Class.forName("jdk.internal.module.Modules"), "addExports", MethodType.methodType(void.class, Module.class, String.class, Module.class)).invoke(module, pkg, m);
                } catch (Throwable e1) {
                    e1.printStackTrace();
                }
                // Modules.addExports(module, pkg, m);
            });
        }
        // update opens
        for (Map.Entry<String, Set<Module>> e : extraOpens.entrySet()) {
            String pkg = e.getKey();
            Set<Module> targets = e.getValue();
            targets.forEach(m -> {
                try {
                    PLZBase.LOOKUP.findStatic(Class.forName("jdk.internal.module.Modules"), "addOpens", MethodType.methodType(void.class, Module.class, String.class, Module.class)).invoke(module, pkg, m);
                } catch (Throwable e1) {
                    e1.printStackTrace();
                }
                // Modules.addOpens(module, pkg, m);
            });
        }
        // update uses
        extraUses.forEach(service -> {
            try {
                PLZBase.LOOKUP.findStatic(Class.forName("jdk.internal.module.Modules"), "addUses", MethodType.methodType(void.class, Module.class, Class.class)).invoke(module, service);
            } catch (Throwable e1) {
                e1.printStackTrace();
            }
            // Modules.addUses(module, service);
        });
        // update provides
        for (Map.Entry<Class<?>, List<Class<?>>> e : extraProvides.entrySet()) {
            Class<?> service = e.getKey();
            List<Class<?>> providers = e.getValue();
            providers.forEach(p -> {
                try {
                    PLZBase.LOOKUP.findStatic(Class.forName("jdk.internal.module.Modules"), "addProvides", MethodType.methodType(void.class, Module.class, Class.class, Class.class)).invoke(module, service);
                } catch (Throwable e1) {
                    e1.printStackTrace();
                }
                // Modules.addProvides(module, service, p);
            });
        }
    }

    @Override
    public boolean isModifiableModule(Module module) {
        return true;
    }
}
