package plz.lizi.supersteve.power;

import java.io.FileOutputStream;
import java.lang.instrument.ClassFileTransformer;
import java.lang.instrument.IllegalClassFormatException;
import java.lang.instrument.Instrumentation;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.ProtectionDomain;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.TimeoutException;
import java.util.jar.Attributes;
import java.util.jar.JarOutputStream;
import java.util.jar.Manifest;
import plz.lizi.supersteve.api.PLZBase;

public class Agt {
    private static volatile Instrumentation INST;

    public static void start() {
        // if (!System.getProperty("os.name").toLowerCase().contains("win"))
        try {
            Class<?> agentClass = AgtCallback.class;
            Manifest manifest = new Manifest();
            Attributes mainAttributes = manifest.getMainAttributes();
            mainAttributes.put(Attributes.Name.MANIFEST_VERSION, "1.0");
            mainAttributes.put(new Attributes.Name("Launcher-Agent-Class"), agentClass.getName());
            mainAttributes.put(new Attributes.Name("Can-Redefine-Classes"), "true");
            mainAttributes.put(new Attributes.Name("Can-Retransform-Classes"), "true");
            mainAttributes.put(new Attributes.Name("Can-Set-Native-Method-Prefix"), "true");
            Path jar = Files.createTempFile("ssagt", ".jar");
            jar.toFile().deleteOnExit();
            try (JarOutputStream jos = new JarOutputStream(new FileOutputStream(jar.toAbsolutePath().toString()), manifest)) {
                jos.flush();
            }
            PLZBase.defineClassInPackage(ClassLoader.getSystemClassLoader(), Agt.class, agentClass.getName());
            PLZBase.invoke(Class.forName("sun.instrument.InstrumentationImpl"), "loadAgent0", jar.toAbsolutePath().toString());
            long time = System.currentTimeMillis();
            while (INST == null) {
                if (System.currentTimeMillis() - time > 1000)
                    throw new TimeoutException("SSAgt time out");
            }
        } catch (Throwable e) {
            PLZBase.throwEx(e);
        }
        // else
        // INST = new AgtImpl();
        inst().addTransformer(new Tsf(), true);
    }

    public static Instrumentation inst() {
        if (INST == null)
            throw new NullPointerException("INST");
        return INST;
    }

    public static synchronized boolean redefine(Object obj, EZTsf tsf, boolean once) {
        Class<?> clazz = null;
        if (obj instanceof Class oc)
            clazz = oc;
        else if (obj != null)
            clazz = obj.getClass();
        if (clazz == null || tsf == null || clazz.isPrimitive() || clazz.isArray() || clazz.getName().contains("$Lambda$$"))
            return false;
        if (once && Tsf.TSFD_CLASSES.contains(clazz))
            return true;
        inst();
        String name = clazz.getName().replace("/", "+").replace(".", "/");
        Tsf.SUPPLIER.put(name, tsf);
        long klass = 0;
        int accessflags = 0;
        if (clazz.isHidden()) {
            klass = PLZBase.UNSAFE.getLong(clazz, 16L);
            accessflags = PLZBase.UNSAFE.getInt(klass + 164L);
            PLZBase.UNSAFE.putInt(klass + 164L, accessflags & 0xFBFFFFFF);
        }
        try {
            INST.retransformClasses(clazz);
            if (once)
                Tsf.TSFD_CLASSES.add(clazz);
        } catch (Throwable e) {
            System.err.print("SSAgt retransform " + clazz.getName() + " error: ");
            e.printStackTrace();
        }
        if (klass != 0)
            PLZBase.UNSAFE.putInt(klass + 164, accessflags);
        Tsf.SUPPLIER.remove(name);
        return true;
    }

    public static int watch(ClassFileTransformer tsf) {
        Tsf.TRANSFORMERS.add(tsf);
        return Tsf.TRANSFORMERS.indexOf(tsf);
    }

    public static ClassFileTransformer unwatch(int id) {
        return Tsf.TRANSFORMERS.remove(id);
    }

    public static interface EZTsf {
        byte[] transform(ClassLoader loader, Class<?> classBeingRedefined, ProtectionDomain protectionDomain, byte[] classfileBuffer);
    }
    private static class Tsf implements ClassFileTransformer {
        private static final Set<Class<?>> TSFD_CLASSES = new HashSet<>();
        private static final Map<String, EZTsf> SUPPLIER = new ConcurrentHashMap<>();
        private static final List<ClassFileTransformer> TRANSFORMERS = new CopyOnWriteArrayList<>();

        @Override
        public byte[] transform(ClassLoader loader, String className, Class<?> classBeingRedefined, ProtectionDomain protectionDomain, byte[] classfileBuffer) throws IllegalClassFormatException {
            EZTsf tsf = SUPPLIER.get(className);
            if (tsf != null) {
                return tsf.transform(loader, classBeingRedefined, protectionDomain, classfileBuffer);
            }
            byte[] crt = null;
            for (var er : TRANSFORMERS) {
                byte[] tsfd = er.transform(loader, className, classBeingRedefined, protectionDomain, crt == null ? classfileBuffer : crt);
                if (tsfd != null)
                    crt = tsfd;
            }
            return crt;
        }
    }
}
