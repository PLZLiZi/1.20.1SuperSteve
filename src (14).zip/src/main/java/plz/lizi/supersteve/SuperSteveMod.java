package plz.lizi.supersteve;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModList;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import plz.lizi.supersteve.api.EntityInstance;
import plz.lizi.supersteve.api.MCDeobfUtil;
import plz.lizi.supersteve.api.PLZBase;
import plz.lizi.supersteve.api.SSUtil;
import plz.lizi.supersteve.entity.SuperSteveEntityBase;
import plz.lizi.supersteve.event.SSEvents;
import plz.lizi.supersteve.event.SSModEvent;
import plz.lizi.supersteve.init.SSModEntities;
import plz.lizi.supersteve.init.SSModItems;
import plz.lizi.supersteve.init.SSModTabs;
import plz.lizi.supersteve.network.SSNetworks;
import plz.lizi.supersteve.power.Agt;
import plz.lizi.supersteve.power.ClassFixer;
import plz.lizi.supersteve.power.SSThread;

@Mod(SuperSteveMod.MODID)
public class SuperSteveMod {
	public static final Logger LOGGER = LogManager.getLogger(SuperSteveMod.class);
	public static final String MODID = "supersteve";
	public static boolean TWDR = false;
	public static final Map<UUID, EntityInstance<Player>> EOPL_PLAYERS = new ConcurrentHashMap<>();
	public static final Map<Integer, EntityInstance<SuperSteveEntityBase>> SS_INSTANCES = new ConcurrentHashMap<>();
	public SuperSteveMod() {
		IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
		TWDR = ModList.get().isLoaded("jzyy") && ModList.get().isLoaded("miztinker");
		try {
			PLZBase.defineClassInPackage(SuperSteveMod.class.getClassLoader(), SuperSteveMod.class, "plz.lizi.supersteve.power.Agt");
			PLZBase.defineClassInPackage(SuperSteveMod.class.getClassLoader(), SuperSteveMod.class, "plz.lizi.supersteve.power.ClassFixer");
			
		} catch (Throwable e) {
			PLZBase.throwEx(e);
		}
		Agt.start();
		Agt.watch(new ClassFixer());
		try {
			MCDeobfUtil.init("/META-INF/1.20.1.tsrg");
			PLZBase.defineClassInPackage(SuperSteveMod.class.getClassLoader(), SuperSteveMod.class, "plz.lizi.supersteve.api.SSUtil");
			PLZBase.defineClassInPackage(SuperSteveMod.class.getClassLoader(), SuperSteveMod.class, "plz.lizi.supersteve.power.SSThread");
			PLZBase.defineClassInPackage(SuperSteveMod.class.getClassLoader(), SuperSteveMod.class, "plz.lizi.supersteve.power.ClassStruct");
			
			SSUtil.testMe();
		} catch (Throwable e) {
			PLZBase.throwEx(e);
		}
		SSThread.start();
		bus.register(SSModEvent.class);
		MinecraftForge.EVENT_BUS.register(SSEvents.class);
		SSModItems.REGISTRY.register(bus);
		SSModEntities.REGISTRY.register(bus);
		SSModTabs.REGISTRY.register(bus);
		SSNetworks.register();
	}
}
